<?php 
	include("header.phtml");
	
	if(!isset($_SESSION['id_user'])){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login.php">';
 }
$error='';
if(isset($_POST['enregistrer'])){
	$password_anc=md5($_POST['password_anc']);
	$password_1=$_POST['password_1'];
	$password_2=$_POST['password_2'];
    if($password_1==$password_2){
		if($password_anc==$users->get_info('password', $id_user)){
			$password=md5($password_1);
			$response = $db->prepare('UPDATE users SET password= :password where id_user = :id_user');
			$response->execute(array('password'=>$password, 'id_user'=>$id_user));
			if($response){
				echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'ChangePassword.php?update=true">';
			}else{
				echo"<meta http-equiv='refresh' content='0; URL=".$url_site."ChangePassword.php?update=false'>";
			}
		}else{
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."ChangePassword.php?update=PFalse'>";
		}
	}else{
		echo"<meta http-equiv='refresh' content='0; URL=".$url_site."ChangePassword.php?update=IFalse'>";
	}
}
?>

<div class="checkout">
	<div class="container">
		<div class="new_arrivals">
		   <h3>Changer le<span> mot de passe</span></h3>
		</div>
		<?php
		if(isset($_GET['update'])){
			if($_GET['update'] == "true"){
				echo "<br><div class='alert alert-success'>
					<strong>Votre mot de passe a bien été changé.</strong>
				</div>";
			}elseif($_GET['update'] == "false"){
				echo "<br><div class='alert alert-danger'>
					<strong>Erreur serveur, veuillez réessayer ultérieurement.</strong>
				</div>";
			}elseif($_GET['update'] == "IFalse"){
				echo "<br><div class='alert alert-danger'>
					<strong>Vos deux mots de passe ne sont pas identiques.</strong>
				</div>";
			}elseif($_GET['update'] == "PFalse"){
				echo "<br><div class='alert alert-danger'>
					<strong>Le mot de passe actuel est incorrect.</strong>
				</div>";
			}
		}
		?>
		<div class="col-sm-6 col-sm-offset-3">
			<div class="panel panel-warning">
				<div class="panel-body">
					<form method="post" action="">
						<div class="form-group">
							<div class="label-column">
								<label for="password_anc" class="control-label"><strong>Mot de passe actuel</strong></label>
							</div>
							<div class="input-column">
								<input type="password" name="password_anc" placeholder="Mot de passe actuel " class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<div class="label-column">
								<label for="password_1" class="control-label"><strong>Nouveau Mot de Passe</strong></label>
							</div>
							<div class="input-column">
								<input type="password" name="password_1" placeholder="Nouveau Mot de Passe" class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<div class="label-column">
								<label for="password_2" class="control-label"><strong>Retapez le Nouveau Mot de Passe</strong></label>
							</div>
							<div class="input-column">
								<input type="password" name="password_2" placeholder="Retapez le Mot de Passe" class="form-control" />
							</div>
						</div><br>
						<div class="form-group">
						<button class="btn btn-primary submit-button" type="submit" name="enregistrer">Enregistrer </button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include"footer.phtml"; ?>