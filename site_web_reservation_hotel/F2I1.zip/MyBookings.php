<?php include"header.phtml";
if(!isset($_SESSION['id_user'])){
	echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login.php">';
}
?>
<!-- check out -->
<div class="row">
	<div class="container">
		<h3><strong> Mes réservation </strong></h3>
		<div class="table-responsive checkout-right animated wow slideInUp" data-wow-delay=".5s">
			<table class="table table-striped">
				<thead>
					<tr>
						<th> N° commande </th>
						<th> Date de reservation </th>
						<th> Date debut </th>
						<th> Date debut </th>
						<th> Total </th>
						<th> Status </th>
						<th> # </th>
					</tr>
				</thead>
				<?php
				if(isset($id_user)){
					$response = $db->prepare('select * from booking where id_user= :id_user order by id_booking desc');
					$response->execute(array('id_user'=>$id_user));
					if($response->rowCount() > 0){
					while($row=$response->fetch()){
                ?>
					<tr class="rem1">
						<td class="invert col-sm-2"><a href="<?=$url_site?>booking_detail.php?id_booking=<?=$row['id_booking']?>"><?=$row['id_booking']?></a></td>
						<td class="invert col-sm-2"><?=$row['booking_date']?></td>
						<td class="invert col-sm-2"><?=$row['start_date']?></td>
						<td class="invert col-sm-2"><?=$row['end_date']?></td>
						<td class="invert col-sm-2"><?=get_booking_cost($row['id_booking'])?> €</td>
						<td class="invert col-sm-2">
						<?php
							$statu = $row['statu'];
							if($statu == 0){
								echo 'Attente de Confirmation';
							}elseif($statu == 1){
								echo 'Confirmer';
							}else{
								echo 'Annuler';
							}
						?>
						</td>
						<td class="invert col-sm-2"><a href="<?=$url_site?>booking_detail.php?id_booking=<?=$row['id_booking']?>">Plus de détail</a></td>
					</tr>
                    <?php
					    /*}*/
					}
				}else{
					echo "<tr><td colspan=7 class='text-center fw-bolder fs-4'>Vous n'avez pas de réservation </td></tr>";
					}
				}
                    ?>
			</table>
		</div>
	</div>
</div>
<!-- //check out -->
<?php include"footer.phtml";?>