<?php include"header.phtml";?>
<br><br><br><br><br>
<div class="container">
	<div class="new_arrivals">
	    <h3>Merci de passer votre commande</h3>
    </div>
</div>
<br><br><br><br><br>
<?php include"footer.phtml";?>
