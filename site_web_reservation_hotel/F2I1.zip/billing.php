<?php 
	include("header.phtml");
	
	if(!isset($_SESSION['id_user'])){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login">';
 }

?>
<div class="container">
	<br><br><div class="row">
	<?php
	if(isset($_GET['add'])){
		if($_GET['add'] == "true"){
			echo "<br><div class='alert alert-success'>
				<strong>Votre adresse a ete bien ajouté</strong>
			</div>";
		}elseif($_GET['add'] == "false"){
			echo "<br><div class='alert alert-danger'>
				<strong>Erreur servenu</strong>
			</div>";
		}
	}
	?>
<?php
if(isset($_GET['idAddress'])){
	$id_address = intval($_GET['idAddress']);
	$sql="select * from address where id_user=$id_user and id_address = $id_address";
	$query=mysqli_query($conn,$sql);
	$num=mysqli_num_rows($query);
	if($num == 1){
		$row = mysqli_fetch_array($query);
?>
<div class="new_arrivals">
   <h3>Modifier <span>votre adresse</span></h3>
</div>
<div class="col-sm-6 col-sm-offset-3">
    <div class="panel panel-warning">
        <div class="panel-body">
		
            <form method="post" action="">
                <input type="hidden" name="command" />
                <div align="center"  class="col-sm-10 col-sm-offset-1">
                    <p class="col-sm-12"><input class="form-control" type="text" name="full_name" placeholder=" Nom & Prenom " value="<?=$row['full_name']?>" /></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="address" placeholder=" Adress " value="<?=$row['address']?>" /></p><br><br>
					<p class="col-sm-12"><textarea class="form-control" name="AdComp" placeholder="Complémentaire"><?=$row['AdComp']?></textarea></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="city" placeholder=" Ville " value="<?=$row['city']?>" /></p><br><br>
                    <p class="col-sm-6"><input class="form-control" type="text" name="region" placeholder=" Région  " value="<?=$row['region']?>" /></p>
                    <p class="col-sm-6"><input class="form-control" type="text" name="zip_code" placeholder=" Code postal " value="<?=$row['zip_code']?>" /></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="phone" placeholder=" Telephone " value="<?=$row['phone']?>" /></p><br><br>
					<p class="col-sm-12"><input class="" type="checkbox" name="defaultAd" value="setDefaultAd"/> Définir par défaut </p><br><br>
                    <p><input name="update" class="btn btn-primary" type="submit" value="Modifier cette adresse" /></p>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
	}else{
		echo"<meta http-equiv='refresh' content='0; URL=".$url_site."billing?update=false'>";
	}
}else{
?>
<div class="new_arrivals">
   <h3>Ajouter <span>une adresse</span></h3>
</div>
<div class="col-sm-6 col-sm-offset-3">
    <div class="panel panel-warning">
        <div class="panel-body">
		
            <form method="post" action="">
                <input type="hidden" name="command" />
                <div align="center"  class="col-sm-10 col-sm-offset-1">
                    <p class="col-sm-12"><input class="form-control" type="text" name="full_name" placeholder=" Nom & Prenom " /></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="address" placeholder=" Adress " /></p><br><br>
					<p class="col-sm-12"><textarea class="form-control" name="AdComp" placeholder="Complémentaire" ></textarea></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="city" placeholder=" Ville " /></p><br><br>
                    <p class="col-sm-6"><input class="form-control" type="text" name="region" placeholder=" Région  " /></p>
                    <p class="col-sm-6"><input class="form-control" type="text" name="zip_code" placeholder=" Code postal " /></p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="phone" placeholder=" Telephone " /></p><br><br>
					<p class="col-sm-12"><input class="" type="checkbox" name="defaultAd" value="setDefaultAd"/> Définir par défaut </p><br><br>
                    <p><input name="submit" class="btn btn-primary" type="submit" value="Ajouter cette adresse" /></p>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
}
?>
</div>
</div>
<?php
if(isset($_POST['submit']) && !empty($_POST['full_name']) && !empty($_POST['address']) && !empty($_POST['phone']) && !empty($_POST['zip_code']) && !empty($_POST['city']) && !empty($_POST['region']))
	{
		$full_name=$_POST['full_name'];
		$address=$_POST['address'];
		$city=$_POST['city'];
		$zip_code=$_POST['zip_code'];
		$phone=$_POST['phone'];
		$region=$_POST['region'];
		$country="France";
		$AdComp=$_POST['AdComp'];
		$id_user=$_SESSION['id_user'];
		$getAdd=get_adress(0);
		if($getAdd == 0)
		{
			$result=insert_address($id_user, $full_name, $address, $city, $zip_code, $region, $country, $AdComp, $phone, 1);
		}else{
			if (!empty($_POST['defaultAd'])){
				$id = get_adress(0);
				$update = "update address set defaultAd = 0 where id_adress = $id";
				$updt=mysqli_query($conn, $update);
				$result=insert_address($id_user, $full_name, $address, $city, $zip_code, $region, $country, $AdComp, $phone, 1);
			}else{
				$result=insert_address($id_user, $full_name, $address, $city, $zip_code, $region, $country, $AdComp, $phone, 0);
			}
			
		}
		
		
		if($result){
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."billing?add=true'>";
		}else{
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."billing?add=false'>";
		}
	}
if(isset($_POST['update']) && !empty($_POST['full_name']) && !empty($_POST['address']) && !empty($_POST['phone']) && !empty($_POST['zip_code']) && !empty($_POST['city']) && !empty($_POST['region'])){
	if($_GET['idAddress'] !=""){
		$id_address = $_GET['idAddress'];
		$full_name = $_POST['full_name'];
		$phone = $_POST['phone'];
		$address = $_POST['address'];
		$zip_code = $_POST['zip_code'];
		$city = $_POST['city'];
		$region = $_POST['region'];
		$AdComp = $_POST['AdComp'];
		$sql = "update address set 
				full_name = '$full_name', phone = '$phone', address = '$address', zip_code = '$zip_code', city = '$city', AdComp = '$AdComp', region = '$region'
				where id_address = '$id_address' and id_user = '$id_user'";
		$query = mysqli_query($conn, $sql);
		if($query){
			echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'billing?update=true&idAddress='.$id_address.'">';
		}else{
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."billing?update=false'>";
		}
	}else{
		echo"<meta http-equiv='refresh' content='0; URL=".$url_site."billing?update=false'>";
	}
}
function insert_address($id_user, $full_name, $address, $city, $zip_code, $region, $country, $AdComp, $phone, $defaultAd){
	global $db;
	$response = $db->prepare('insert into address (id_user, full_name, address, city, zip_code, region, country, AdComp, phone, defaultAd) 
	values(:id_user, :full_name, :address, :city, :zip_code, :region, :country, :AdComp, :phone, :defaultAd)');
	$response->execute(array('id_user'=>$id_user, 'full_name'=>$full_name, 'address'=>$address, 'city'=>$city, 'zip_code'=>$zip_code, 'region'=>$region, 'country'=>$country, 'AdComp'=>$AdComp, 'phone'=>$phone, 'defaultAd'=>$defaultAd));
	return $response;
	}
?>
<?php include"footer.phtml"; ?>