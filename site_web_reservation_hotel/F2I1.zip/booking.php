<?php include"header.phtml";
 ?>
	<div class="container">
			<?php
			if(isset($_GET['date_debut']) && isset($_GET['date_fin']) && isset($_GET['category']) && isset($_GET['adults']) && isset($_GET['children']) && isset($_GET['city']))
			{
				$date_debut=trim($_GET["date_debut"]);	
				$date_fin=trim($_GET["date_fin"]);	
				$category=trim($_GET["category"]);
				$adults=intval($_GET["adults"]);	
				$children=intval($_GET["children"]);	
				$max_person = $adults + $children;
				$city = trim($_GET["city"]);
	/*
		Place code to connect to your DB here.
	*/
	// include your code to connect to DB.

	$tbl_name="products";		//your table name
	// How many adjacent pages should be shown on each side?
	$adjacents = 3;
	$targetpage = "index.php?category=".$category;
	if($category == "all"){
		$query = "SELECT COUNT(*) as num FROM $tbl_name where products.id_product NOT IN (SELECT booking.id_product FROM booking WHERE booking.start_date < '$date_debut' AND booking.end_date > '$date_fin') AND max >= $max_person AND city = '$city'";
	}else{
		$query = "SELECT COUNT(*) as num FROM $tbl_name where products.id_product NOT IN (SELECT booking.id_product FROM booking WHERE booking.start_date < '$date_debut' AND booking.end_date > '$date_fin') AND max >= $max_person AND city = '$city'";
	}
	
	/* 
	   First get total number of rows in data table. 
	   If you have a WHERE clause in your query, make sure you mirror it here.
	*/
	$query_test = mysqli_query($conn, $query);
	if(!$query_test){
		die('Erreur de requête SQL : '.mysqli_error($conn));
	}
	$total_pages = mysqli_fetch_array($query_test);
	$total_pages = $total_pages['num'];
	
	/* Setup vars for query. */
	
	$limit = 16; 								//how many items to show per page
	if(isset($_GET['page'])){
	$page = $_GET['page'];
	}else{
		$page = 1;
	}
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
	
	/* Get data. */
	if($category == "all"){
		$sql = "SELECT * FROM $tbl_name p where p.id_product NOT IN (SELECT b.id_product FROM booking b WHERE b.start_date < '$date_debut' AND b.end_date > '$date_fin') AND max >= $max_person AND city = '$city' LIMIT $start, $limit";
	}else{
		$sql = "SELECT * FROM $tbl_name p where p.id_product NOT IN (SELECT b.id_product FROM booking b WHERE b.start_date < '$date_debut' AND b.end_date > '$date_fin') AND id_category = $category AND max >= $max_person AND city = '$city' LIMIT $start, $limit";
	}
	$result = mysqli_query($conn, $sql);
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	/* 
		Now we apply our rules and draw the pagination object. 
		We're actually saving the code to a variable in case we want to draw it more than once.
	*/
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= '
  <ul class="pagination paging">';
		//previous button
		if ($page > 1) 
			$pagination.= '<li>
      <a href="'.$targetpage.'?page='.$prev.'" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>';
		else
			$pagination.= '<li class="disabled">
      <a href="#" tabindex="-1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>';	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= '<li class="active">
      <a href="#">'.$counter.' <span class="sr-only">(current)</span></a>
    </li>';
				else
					$pagination.= '<li><a href="'.$targetpage.'?page='.$counter.'">'.$counter.'</a></li>';					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= '<li class="active">
      <a href="#">'.$counter.' <span class="sr-only">(current)</span></a>
    </li>';
					else
						$pagination.= '<li ><a href="'.$targetpage.'?page='.$counter.'">'.$counter.'</a></li>';					
				}
				$pagination.= "...";
				$pagination.= '<li><a href="'.$targetpage.'?page='.$lpm1.'">'.$lpm1.'</a></li>';
				$pagination.= '<li><a href="'.$targetpage.'?page='.$lastpage.'">'.$lastpage.'</a></li>';		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= '<li><a href="'.$targetpage.'?page=1">1</a></li>';
				$pagination.= '<li><a href="'.$targetpage.'?page=2">2</a></li>';
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= '<li class="active">
      <a href="#">'.$counter.' <span class="sr-only">(current)</span></a>
    </li>';
					else
						$pagination.= '<li><a href="'.$targetpage.'?page='.$counter.'">'.$counter.'</a></li>';					
				}
				$pagination.= "...";
				$pagination.= '<li><a href="'.$targetpage.'?page='.$lpm1.'">'.$lpm1.'</a></li>';
				$pagination.= '<li><a href="'.$targetpage.'?page='.$lastpage.'">'.$lastpage.'</a></li>';		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= '<li><a href="'.$targetpage.'?page=1">1</a></li>';
				$pagination.= '<li><a href="'.$targetpage.'?page=2">2</a></li>';
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= '<li class="active">
      <a href="#">'.$counter.' <span class="sr-only">(current)</span></a>
    </li>';
					else
						$pagination.= '<li><a href="'.$targetpage.'?page='.$counter.'">'.$counter.'</a></li>';					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= '<li>
      <a href="'.$targetpage.'?page='.$next.'" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>';
		else
			$pagination.= '<li class="disabled">
      <a href="" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>';
		$pagination.= "</ul>\n";		
	}
?>
<section style="background-color: #eee;">
  <div class="container py-5">
	<?php
		while($row = mysqli_fetch_array($result))
		{
	
		// Your while loop here
		?>
		<div class="row justify-content-center mb-3">
		  <div class="col-md-12 col-xl-10">
			<div class="card shadow-0 border rounded-3">
			  <div class="card-body">
				<div class="row">
				  <div class="col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0">
					<div class="bg-image hover-zoom ripple rounded ripple-surface">
						<?php
							$path = $product->get_image($row['id_product']);
							echo'<a href="'.$url_site.'Product/'.$row["id_product"].'"><img src="'.$url_site.$path.'" alt="" class="w-100"></a>';
							$name = str_replace(' ', '-', $row['name']);
						?>
						<a href="#!">
						<div class="hover-overlay">
						  <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>
						</div>
					  </a>
					</div>
				  </div>
					
					<div class="col-md-6 col-lg-6 col-xl-6">
						<h5><?php
						$contenu = $row['name'];
						$length = 30; // on veut les 256 premiers caratères
						if(strlen($contenu) > $length) { // si la longueur de $contenu est plus grande que $length
							echo substr($contenu,0,$length).'...'; /* alors on coupe $contenu à partir du début (0) jusqu'à $length (soit 256) et tout ce qui vient ensuite sera remplacé par "..." */
							
						}else{
							echo $contenu;
						}
						 ?></h5>
						<div class="d-flex flex-row">
						  <div class="text-danger mb-1 me-2">
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
						  </div>
							
						  <span><?php 
							list($note,$total)=get_review($row['id_product']);
							echo $note;
								
							?>	</span>
						</div>
						<div class="mt-1 mb-0 text-muted small">
						  <span>100% cotton</span>
						  <span class="text-primary"> • </span>
						  <span>Light weight</span>
						  <span class="text-primary"> • </span>
						  <span>Best finish<br /></span>
						</div>
						<div class="mb-2 text-muted small">
						  <span>Unique design</span>
						  <span class="text-primary"> • </span>
						  <span>For men</span>
						  <span class="text-primary"> • </span>
						  <span>Casual<br /></span>
						</div>
						<p class="text-truncate mb-4 mb-md-0">
						  There are many variations of passages of Lorem Ipsum available, but the
						  majority have suffered alteration in some form, by injected humour, or
						  randomised words which don't look even slightly believable.
						</p>
					</div>
					<div class="col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start">
						<div class="d-flex flex-row align-items-center mb-1">
						  <?php
								if(!empty($row['price_sold']) || $row['price_sold']!=0){
									echo '<h4 class="mb-1 me-1">'.$row['price_sold'].'€</h4>
									<span class="text-danger"><s>'.$row['price'].'€</s></span>';
								}else{
									echo '<h4 class="mb-1 me-1">'.$row['price'].'€</h4>';
								}
						  ?>
						</div>
						<div class="d-flex flex-column mt-4">
						  <button onclick="location.href='<?php echo $url_site.'details.php?id='.$row['id_product'].'&date_debut='.$date_debut.'&date_fin='.$date_fin.'&adults='.$adults.'&children='.$children?>'" class="btn btn-primary btn-sm" type="button">Réserver maintenant</button>
						</div>
					</div>
						
				</div>
          </div>
        </div>
      </div>
    </div>
	  <?php } ?>
           
  </div>
  <div class="pagination-grid text-right">
		<?php echo $pagination?>
	</div>
</section>
<?php }else{
	echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
}?>
</div>
<script>
function addfavorie(id_product){
	$.ajax({
		url: '<?=$url_site?>favorites.php',
		type: 'POST',
		data: {id:id_product},
		dataType:"JSON",
		success: function(data){
			if(data.dataV == 0){
				$(".favorites"+id_product).removeClass("text-default");
				$(".favorites"+id_product).addClass("text-primary");
			}else{
				$(".favorites"+id_product).removeClass("text-primary");
				$(".favorites"+id_product).addClass("text-default");
			}
		}
	});
}
</script>
<?php include'footer.phtml';?>