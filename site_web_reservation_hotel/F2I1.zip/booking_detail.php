<?php include"header.phtml";
if(!isset($_SESSION['id_user'])){
	echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login.php">';
}
?>
<div class="row">
	<div class="container">
	<div class="checkout-left">	
				
		<div class="checkout-right-basket animated wow slideInRight" data-wow-delay=".5s">
			<a href="<?=$url_site?>Mybookings.php"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span> Retour à mes commandes </a>
		</div>
		<div class="clearfix"> </div>
	</div>
		<h3><strong> Detail commande </strong></h3>
<?php		
	
	$id_booking=valid_donnees($_GET['id_booking']);
	if($id_user == get_user_booking($id_booking)){
		$response = $db->prepare('select * from booking where id_booking= :id_booking and id_user = :id_user');
		$response->execute(array('id_booking'=>$id_booking, 'id_user'=>$id_user));
		$rows= $response->fetch();
		$id_billing = $rows['id_billing'];
		$response = $db->prepare('select * from billing where id_billing= :id_billing');
		$response->execute(array('id_billing'=>$id_billing));
		$row= $response->fetch();
?>
	<div class="card">
        <div class="card-header">
            <strong> Information de livraison </strong>
        </div>
        <div class="card-body">
	Nom & Prenom : <strong><?=$row['full_name']?></strong><br>
	Adresse de livraison : <strong><?=$row['address']?>,<?=$row['zip_code']?> - <?=$row['city']?>, <?=$row['country']?></strong><br>
	Telephone : <strong><?=$row['phone']?></strong><br>
		</div>
    </div>
	<div class="row">
		<div class="card">
			<div class="card-header">
				Description
			</div>
			<div class="card-body">
				<p class="card-text">
					Date de réservation : <strong><?=$rows['booking_date']?></strong><br>
					Date debut : <strong><?=$rows['start_date']?></strong><br>
					Date de fin : <strong><?=$rows['end_date']?></strong><br>
				</p>
			</div>
		</div>
	</div>
		<?php
		}else{
			echo "<div class='alert alert-danger'><strong>Nous n'avons pas pu trouvez votre commande</strong></div>";
		}
		?>
	</div>
</div>
<!-- //check out -->
<?php include"footer.phtml";?>