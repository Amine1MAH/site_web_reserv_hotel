<?php include'header.phtml'; 

if(isset($_POST['envoyer'])){
	$nom=$_POST['nom'];
	$email=$_POST['email'];
	$sujet=$_POST['sujet'];
	$message=$_POST['message'];
	$response = $db->prepare('insert into messages (nom, email, sujet, message) values(:nom,:email,:sujet,:message)');
	$response->execute(array('nom'=>$nom, 'email'=>$email, 'sujet'=>$sujet, 'message'=>$message));
	if($response){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'contact.php?sent=true">';
	}
}
?>
<!-- contact -->
	<div class="container">
	<?php
		if(isset($_GET['sent'])){
			if($_GET['sent'] == 'true'){
			echo"<div class='alert alert-success'><strong>Merci de nous contacter on va vous repondres le plus bref delai</strong></div>";
			}else{
				echo"<div class='alert alert-danger'><strong>Probleme intervenue</strong></div>";
			}
		}
		?>
    <div class="row justify-content-center">
      <div class="col-md-4 mt-5 bg-light rounded">
        <h1 class="text-center font-weight-bold text-primary">Contactez nous</h1>
        <hr class="bg-light">
        <h5 class="text-center text-success"></h5>
        <form action="" method="post" id="form-box" class="p-2">
          <div class="form-group input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" name="nom" class="form-control" placeholder="Enter your name" required>
          </div>
          <div class="form-group input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
          </div>
          <div class="form-group input-group">
            <span class="input-group-text"><i class="fas fa-at"></i></span>
            <input type="text" name="sujet" class="form-control" placeholder="Enter subject" required>
          </div>
          <div class="form-group input-group">
            <span class="input-group-text"><i class="fas fa-comment-alt"></i></span>
            <textarea name="message" id="msg" class="form-control" placeholder="Write your message" cols="30" rows="4" required></textarea>
          </div>
          <div class="form-group">
            <input type="submit" name="envoyer" id="submit" class="btn btn-primary btn-block" value="Send">
          </div>
        </form>
      </div>
    </div>
  </div>
	
<!-- //contact -->

<?php include'footer.phtml'; ?>