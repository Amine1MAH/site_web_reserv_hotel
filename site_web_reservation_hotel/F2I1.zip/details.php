<?php include"header.phtml";
$id=intval(valid_donnees($_GET['id']));

if(!empty($id)){
	$date_debut=trim($_GET["date_debut"]);	
	$date_fin=trim($_GET["date_fin"]);
	$adults=trim($_GET["adults"]);	
	$children=trim($_GET["children"]);
	if(isset($_POST['add'])){
	}
	$response = $db->prepare('select * from products where id_product= :id_product');
	$response->execute(array('id_product'=>$id));
	$count=$response->rowCount();
	if($count != 1){
		echo"
			<div class='panel panel-default col-sm-12'>
				<div class='panel-body'>
					<center>Nous n'avons pas trouvé ce produit ".$id."</center>
				</div>
			</div>
		";
	}else{
	$row = $response->fetch();
	
	list($note,$total)=get_review($row['id_product']);
?>

<!-- single -->
<div class="container">
	<div class="row">
		<div class="col-md-6">
			<?php
				$response = $db->prepare('select * from product_pic where id_product= :id_product');
				$response->execute(array('id_product'=>$id));
				$i = 1;
				$count_im=$response->rowCount();
				if($count_im > 0){
			?>
			<div id="myCarousel" class="carousel slide">
				<!-- Indicators -->
				<div class="carousel-indicators">
				<button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true"></button>
				<?php
					
					while($rows= $response->fetch()){
						
						echo '<button type="button" data-bs-target="#myCarousel" data-bs-slide-to="'.$i.'"></button>';
						$i++;
						if($i == $count_im){
							break;
						}
						
					}
				?>
				</div>

				<!-- Wrapper for slides -->
				<div class="carousel-inner">
				<?php
					$response = $db->prepare('SELECT * FROM product_pic where id_product= :id_product');
					$response->execute(array('id_product'=>$id));
					$i = 0;
					while($rows=$response->fetch()){
						if($i == 0){
						echo '<div class="carousel-item active">
							  <img src="'.$url_site.'images/product_pic/'.$rows["path"].'" data-imagezoom="true" class="img-responsive" style="width:100%">
							</div>';
						}else{
							echo '<div class="carousel-item">
							  <img src="'.$url_site.'images/product_pic/'.$rows["path"].'" data-imagezoom="true" class="img-responsive" style="width:100%">
							</div>';
						}
						$i++;
					}
					
				?>
				<button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Previous</span>
			  </button>
			  <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="visually-hidden">Next</span>
			  </button>
			</div>
				</div>

				
			<?php
				}else{
						echo '
						<img src="'.$url_site.'images/no-image-found.png" data-imagezoom="true" class="img-responsive">';
					}
			?>
		</div>
		<div class="col-md-6">
			<div class="booking-form">
			<?php
				if(check_availablity($date_debut, $date_fin, $adults+$children, $id)==0){
					$disabled="";
				}else{
					$disabled="";
					echo"<div class='alert alert-danger' role='alert'>Désolé, l'hôtel n'est pas disponible aux dates choisies. Veuillez sélectionner d'autres dates.</div>";
					
				}
			?>
			<h1><?php echo $row['name']?></h1>
			<div> <a href="#reviews"><i class="fas fa-star text-star mr-1"></i><?php echo $note.' sur 5 | '.$total?> évaluations</a></div>
			
				<form method="get" action="details.php">
					<input type="hidden" name="id" value="<?=$id?>">
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<span class="form-label">Date début</span>
								<input id="date_debut" name="date_debut" class="form-control" type="date" value="<?=$date_debut?>" required>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<span class="form-label">Date fin</span>
								<input id="date_fin" name="date_fin" class="form-control" type="date" value="<?=$date_fin?>" required>
							</div>
						</div>
					</div>
					<div class="row">
					  <div class="col-sm-6">
						<div class="form-group">
						  <span class="form-label">adultes</span>
						  <div>
							<button class="col-sm-1" type="button" onclick="decreaseValue('adults')">-</button>
							<input id="adults" name="adults" class="col-sm-6" type="text" value="<?=$adults?>" required>
							<button class="col-sm-1" type="button" onclick="increaseValue('adults')">+</button>
						  </div>
						</div>
					  </div>
					  <div class="col-sm-6">
						<div class="form-group">
						  <span class="form-label">Enfants</span>
						  <div>
							<button class="col-sm-1" type="button" onclick="decreaseValue('children')">-</button>
							<input id="children" name="children" class="col-sm-6" type="text" value="<?=$children?>" required>
							<button class="col-sm-1" type="button" onclick="increaseValue('children')">+</button>
						  </div>
						</div>
					  </div>
					</div>
					<div><strong>Prix : </strong>
					<?php
						if(!empty($row['price_sold']) || $row['price_sold']!=0){
							echo '<span class="item_price">'.$row['price_sold'].'€/Jour</span><del>'.$row['price'].'€</del>';
						}else{
							echo '<span class="item_price">'.$row['price'].'€/Jour</span>';
						}
					?>
					</div>
					<div>
						<strong>Vous avez séléctionné :</strong>
						<?php
							// Convertir les dates en timestamps
							$timestamp1 = strtotime($_GET['date_debut']);
							$timestamp2 = strtotime($_GET['date_fin']);

							// Calculer la différence en secondes
							$diff_seconds = $timestamp2 - $timestamp1;

							// Convertir la différence en jours
							$count_day = floor($diff_seconds / (60 * 60 * 24));
							echo $count_day;
						?> Jour(s)
					</div>
					<div>
						<strong>Total pour la réservation :</strong> 
						<?php
							if(!empty($row['price_sold']) || $row['price_sold']!=0){
								echo $row['price_sold']*$count_day;
							}else{
								echo $row['price']*$count_day;
							}
						?>€
					</div>
					<div class="row">
						<div class="form-btn">
							<button id="check_availablity" class="btn btn-primary" hidden>Voir les disponibilités</button>
							<?php
							if(isset($_SESSION['id_user'])){
							?>
							<a id="reservationButton" class="btn btn-success <?=$disabled?>" data-bs-toggle="modal" data-bs-target="#exampleModal">Réserver maintenant</a>
							<?php
							}else{
							?><a href="<?=$url_site?>login.php" class="btn btn-success <?=$disabled?>">Se connecter pour réserver</a>
							<?php
							}
							?>
						</div>
					</div>
					
				</form>
			</div>
			<?php
				if(isset($_SESSION['id_user'])){
			?>
			<script>
			  function handleDateChange() {
				var reservationButton = document.getElementById("reservationButton");
				reservationButton.classList.add("disabled");
				document.getElementById("check_availablity").removeAttribute("hidden"); // Afficher le bouton

			  }

			  document.getElementById("date_debut").addEventListener("change", handleDateChange);
			  document.getElementById("date_fin").addEventListener("change", handleDateChange);
			</script>
			<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
				<div class="modal-content">
				  <div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Entrez vos données de réservation</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				  </div>
				  <form method='post' action="">
				  <div class="modal-body">
				  <?php
					if(isset($_POST['pay']) && !empty($_POST['name']) && !empty($_POST['address']) && !empty($_POST['name']) && !empty($_POST['zip_code']) && !empty($_POST['city']) && !empty($_POST['mail']) && !empty($_POST['phone'])){
						$name = valid_donnees($_POST['name']);
						$address = valid_donnees($_POST['address']);
						$zip_code = valid_donnees($_POST['zip_code']);
						$city = valid_donnees($_POST['city']);
						$mail = valid_donnees($_POST['mail']);
						$phone = valid_donnees($_POST['phone']);
						$_SESSION['name'] = $name;
						$_SESSION['address'] = $address;
						$_SESSION['zip_code'] = $zip_code;
						$_SESSION['city'] = $city;
						$_SESSION['mail'] = $mail;
						$_SESSION['phone'] = $phone;
						$_SESSION['start_date'] = $_GET['date_debut'];
						$_SESSION['end_date'] = $_GET['date_fin'];
						$_SESSION['id_product'] = $_GET['id'];
						$_SESSION['nb_adults'] = $adults;
						$_SESSION['nb_children'] = $children;
						echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'request.php?id='.$id.'&Address='.$address.'&date_debut='.$date_debut.'&date_fin='.$date_fin.'">';
					}
				  ?>
					
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<span class="form-label">Nom et Prénom</span>
									<input name="name" class="form-control" type="text" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<span class="form-label">Adresse</span>
									<input name="address" class="form-control" type="text" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<span class="form-label">Ville</span>
									<input name="city" class="form-control" type="text" required>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<span class="form-label">Code postal</span>
									<input name="zip_code" class="form-control" type="text" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<span class="form-label">Adresse mail</span>
									<input name="mail" class="form-control" type="text" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<span class="form-label">Téléphone</span>
									<input name="phone" class="form-control" type="text" required>
								</div>
							</div>
						</div>
					
				  </div>
				  <div class="modal-footer">
					<a class="btn btn-secondary" data-bs-dismiss="modal">Annuler</a>
					<button name="pay" type="submit" class="btn btn-primary">Valider et payer par paypal</button>
				  </div>
				</form>
				</div>
			  </div>
			</div>
				<?php } ?>
			<!-- fin Modal -->
		</div>
	</div>
	<div class="clearfix"> </div>
	<div class="row">
		<div class="card">
			<div class="card-header">
				Description
			</div>
			<div class="card-body">
				<p class="card-text"><?=$row['description']?></p>
			</div>
		</div>
	</div>
	<div class="clearfix"> </div>
	<div class="row">
		<div class="card" id="reviews">
			<div class="card-header">Avis</div>
			<div class="card-body">
				<div class="row">
					<div class="col-sm-4 text-center">
						<h1 class="text-star mt-4 mb-4">
							<strong><span id="average_rating">0.0</span> / 5</strong>
						</h1>
						<div class="mb-3">
							<i class="fas fa-star star-light mr-1 main_star"></i>
							<i class="fas fa-star star-light mr-1 main_star"></i>
							<i class="fas fa-star star-light mr-1 main_star"></i>
							<i class="fas fa-star star-light mr-1 main_star"></i>
							<i class="fas fa-star star-light mr-1 main_star"></i>
						</div>
						<h3><span id="total_review">0</span> évaluations</h3>
					</div>
					<div class="col-sm-4">
						<p>
							<div class="progress-label-left"><strong>5</strong> <i class="fas fa-star text-star"></i></div>

							<div class="progress-label-right">(<span id="total_five_star_review">0</span>)</div>
							<div class="progress">
								<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="five_star_progress"></div>
							</div>
						</p>
						<p>
							<div class="progress-label-left"><strong>4</strong> <i class="fas fa-star text-star"></i></div>
							
							<div class="progress-label-right">(<span id="total_four_star_review">0</span>)</div>
							<div class="progress">
								<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="four_star_progress"></div>
							</div>               
						</p>
						<p>
							<div class="progress-label-left"><strong>3</strong> <i class="fas fa-star text-star"></i></div>
							
							<div class="progress-label-right">(<span id="total_three_star_review">0</span>)</div>
							<div class="progress">
								<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="three_star_progress"></div>
							</div>               
						</p>
						<p>
							<div class="progress-label-left"><strong>2</strong> <i class="fas fa-star text-star"></i></div>
							
							<div class="progress-label-right">(<span id="total_two_star_review">0</span>)</div>
							<div class="progress">
								<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="two_star_progress"></div>
							</div>               
						</p>
						<p>
							<div class="progress-label-left"><strong>1</strong> <i class="fas fa-star text-star"></i></div>
							
							<div class="progress-label-right">(<span id="total_one_star_review">0</span>)</div>
							<div class="progress">
								<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="one_star_progress"></div>
							</div>               
						</p>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	<div class="row" id="review_content">
	<?php
		$response = $db->prepare('SELECT * FROM reviews where id_product= :id_product ORDER BY id_review DESC');
		$response->execute(array('id_product'=>$id));
		$html='';
		while($row=$response->fetch())
				{
					$html = $html.'<div class="row mb-3">';

					$html = $html.'<div class="col-sm-12">';

					$html = $html.'<div class="panel panel-default">';

					$html = $html.'<div class="panel-heading"><strong><span class="glyphicon glyphicon-user" aria-hidden="true"></span> '.htmlspecialchars($users->get_full_name($row["id_user"])).'</strong></div>';

					$html = $html.'<div class="panel-body">';

					for($star = 1; $star <= 5; $star++)
					{
						$class_name = '';

						if($row["user_rating"] >= $star)
						{
							$class_name = 'text-star';
						}
						else
						{
							$class_name = 'star-light';
						}

						$html = $html.'<i class="fas fa-star '.$class_name.' mr-1"></i>';
					}

					$html = $html.'<br />';

					$html = $html.''.htmlspecialchars($row["user_review"]);

					$html = $html.'</div>';

					$html = $html.'<div class="panel-footer text-right">En '.$row["datetime"].'</div>';

					$html = $html.'</div>';

					$html = $html.'</div>';

					$html = $html.'</div>';
					
				}
				echo $html;
			?>
	</div>
</div>

<?php }
}else{
	echo"
		<div class='panel panel-default col-sm-12'>
			<div class='panel-body'>
				<center>Nous n'avons pas trouvé ce produit".htmlspecialchars(intval($_GET['id']))."</center>
			</div>
		</div>
	";
} ?>
<script>

function _0x3554(){var _0x2af056=['addClass','3420sTIkPa','#total_one_star_review','three_star_review','ready','#one_star_progress','4055pDdRiq','785953LOHDUG','five_star_review','total_review','ajax','average_rating','#total_two_star_review','POST','1572181QzWZFx','two_star_review','8kLdCOW','ceil','star-light','JSON','#two_star_progress','#five_star_progress','108luhnmV','4223082uYlIac','.main_star','7523244LiMqDX','each','195070zdonNa','791087ceydNE','load_data','four_star_review','4cmKnBf','#total_five_star_review','one_star_review','#total_review','440vBcTuO','text','2KBkRed','width','#total_three_star_review','css'];_0x3554=function(){return _0x2af056;};return _0x3554();}var _0x55a283=_0x5821;function _0x5821(_0x31711a,_0x59f853){var _0x35547a=_0x3554();return _0x5821=function(_0x582100,_0x4779d0){_0x582100=_0x582100-0x1ad;var _0x2f8a8=_0x35547a[_0x582100];return _0x2f8a8;},_0x5821(_0x31711a,_0x59f853);}(function(_0x351237,_0x4556c6){var _0x9ca888=_0x5821,_0x71ed8e=_0x351237();while(!![]){try{var _0x485ccd=-parseInt(_0x9ca888(0x1d3))/0x1*(-parseInt(_0x9ca888(0x1b3))/0x2)+parseInt(_0x9ca888(0x1ce))/0x3*(parseInt(_0x9ca888(0x1ad))/0x4)+-parseInt(_0x9ca888(0x1bd))/0x5*(parseInt(_0x9ca888(0x1b8))/0x6)+parseInt(_0x9ca888(0x1be))/0x7+parseInt(_0x9ca888(0x1c7))/0x8*(-parseInt(_0x9ca888(0x1d0))/0x9)+parseInt(_0x9ca888(0x1d2))/0xa*(parseInt(_0x9ca888(0x1b1))/0xb)+-parseInt(_0x9ca888(0x1cd))/0xc*(parseInt(_0x9ca888(0x1c5))/0xd);if(_0x485ccd===_0x4556c6)break;else _0x71ed8e['push'](_0x71ed8e['shift']());}catch(_0x44456b){_0x71ed8e['push'](_0x71ed8e['shift']());}}}(_0x3554,0xac0d1),$(document)[_0x55a283(0x1bb)](function(){_0x44bd43();function _0x44bd43(){var _0x3a0a2b=_0x5821;$[_0x3a0a2b(0x1c1)]({'url':'<?=$url_site?>review/submit_rating.php','method':_0x3a0a2b(0x1c4),'data':{'action':_0x3a0a2b(0x1d4),'id':0x<?=$id?>},'dataType':_0x3a0a2b(0x1ca),'success':function(_0x1410ce){var _0xec9533=_0x3a0a2b;$('#average_rating')[_0xec9533(0x1b2)](_0x1410ce[_0xec9533(0x1c2)]),$(_0xec9533(0x1b0))[_0xec9533(0x1b2)](_0x1410ce[_0xec9533(0x1c0)]);var _0xac1732=0x0;$(_0xec9533(0x1cf))[_0xec9533(0x1d1)](function(){var _0x20da18=_0xec9533;_0xac1732++,Math[_0x20da18(0x1c8)](_0x1410ce[_0x20da18(0x1c2)])>=_0xac1732&&($(this)[_0x20da18(0x1b7)]('text-warning'),$(this)[_0x20da18(0x1b7)](_0x20da18(0x1c9)));}),$(_0xec9533(0x1ae))[_0xec9533(0x1b2)](_0x1410ce[_0xec9533(0x1bf)]),$('#total_four_star_review')['text'](_0x1410ce[_0xec9533(0x1d5)]),$(_0xec9533(0x1b5))[_0xec9533(0x1b2)](_0x1410ce[_0xec9533(0x1ba)]),$(_0xec9533(0x1c3))[_0xec9533(0x1b2)](_0x1410ce[_0xec9533(0x1c6)]),$(_0xec9533(0x1b9))['text'](_0x1410ce[_0xec9533(0x1af)]),$(_0xec9533(0x1cc))['css'](_0xec9533(0x1b4),_0x1410ce[_0xec9533(0x1bf)]/_0x1410ce[_0xec9533(0x1c0)]*0x64+'%'),$('#four_star_progress')['css'](_0xec9533(0x1b4),_0x1410ce[_0xec9533(0x1d5)]/_0x1410ce['total_review']*0x64+'%'),$('#three_star_progress')[_0xec9533(0x1b6)](_0xec9533(0x1b4),_0x1410ce[_0xec9533(0x1ba)]/_0x1410ce[_0xec9533(0x1c0)]*0x64+'%'),$(_0xec9533(0x1cb))['css']('width',_0x1410ce['two_star_review']/_0x1410ce[_0xec9533(0x1c0)]*0x64+'%'),$(_0xec9533(0x1bc))[_0xec9533(0x1b6)](_0xec9533(0x1b4),_0x1410ce[_0xec9533(0x1af)]/_0x1410ce['total_review']*0x64+'%');}});}}));

</script>
<script>
function reset () {
			$("#toggleCSS").attr("href", "<?=$url_site?>css/alertify.default.css");
			alertify.set({
				labels : {
					ok     : "OK",
					cancel : "Cancel"
				},
				delay : 5000,
				buttonReverse : false,
				buttonFocus   : "ok"
			});
		}

		// ==============================
		// Standard Dialogs
		$("#alert").on( 'click', function () {
			reset();
			alertify.alert("This is an alert dialog");
			return false;
		});
</script>
<!-- //single -->
<?php include"footer.phtml";?>