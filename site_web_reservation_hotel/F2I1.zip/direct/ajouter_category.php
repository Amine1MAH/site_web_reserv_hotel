<?php include("header.php");
   include ('includes/upload_img.php');
if(isset($_POST['enregistrer'])){
	$nom=mysqli_real_escape_string($conn, $_POST['nom']);
	$keywords=mysqli_real_escape_string($conn, $_POST['keywords']);
	$description=mysqli_real_escape_string($conn, $_POST['elm1']);
	$categorie=intval(mysqli_real_escape_string($conn, $_POST['categorie']));
	$prix=intval(mysqli_real_escape_string($conn, $_POST['prix']));
	$numberCat=mysqli_real_escape_string($conn, $_POST['numberCat']);
	$numberPic=mysqli_real_escape_string($conn, $_POST['numberPic']);
	$sql="insert into products (id_category, keywords, name, description, price, price_sold) values($categorie,'$keywords','$nom','$description',$prix,0);";
	$query=mysqli_query($conn,$sql);
	$id_product = mysqli_insert_id($conn);
	if($query){
		for ($i=1; $i<=$numberPic; $i++){
			if (isset($_FILES['pic-'.$i])){
			
				$file_name='test/'.basename($_FILES['pic-'.$i]['name']);
				$file_path=$_FILES['pic-'.$i]['tmp_name'];
				$upload_img = new Upload_img($file_name,$file_path, $id_product, $i);
				
			}
		}
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/produit.php?upload=true">';
	}else {
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/produit.php?upload=false">';
	}
}
?>
<div class="row">
    <div class="col-md-12">
        <h2>Ajouter un produit</h2>
    </div>
</div>
<?php
if(isset($_GET['upload'])){
	if($_GET['upload'] == "true"){
		echo "<br><div class='alert alert-success'>
			<strong>Le produit à étè bien ajouté</strong>
		</div>";
	}elseif($_GET['upload'] == "false"){
		echo "<br><div class='alert alert-danger'>
			<strong>Erreur servenu</strong>
		</div>";
	}
}
?>
                 <hr />
<div class="row">
    <div class="col-md-12">
	    <form method="post" enctype="multipart/form-data" class="form-horizontal custom-form">
            <div class="form-group">
                <div class="col-sm-2 label-column">
                    <label for="name-input-field" class="control-label"><strong>Nom de Catégorie*</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="text" name="category_name" placeholder="Nom de Produit" class="form-control" />
                </div>
            </div>
            <button class="btn btn-primary submit-button" type="submit" name="enregistrer">Enregistrer </button>
        </form>
    </div>
</div>
<?php include("footer.php"); ?>