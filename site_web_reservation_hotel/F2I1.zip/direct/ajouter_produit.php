<?php include("header.php");
   include ('includes/upload_img.php');
if(isset($_POST['enregistrer'])){
	$nom=mysqli_real_escape_string($conn, $_POST['nom']);
	$keywords=mysqli_real_escape_string($conn, $_POST['keywords']);
	$description=mysqli_real_escape_string($conn, $_POST['elm1']);
	$categorie=intval(mysqli_real_escape_string($conn, $_POST['categorie']));
	$prix=intval(mysqli_real_escape_string($conn, $_POST['prix']));
	$numberCat=mysqli_real_escape_string($conn, $_POST['numberCat']);
	$numberPic=mysqli_real_escape_string($conn, $_POST['numberPic']);
	$sql="insert into products (id_category, keywords, name, description, price, price_sold) values($categorie,'$keywords','$nom','$description',$prix,0);";
	$query=mysqli_query($conn,$sql);
	$id_product = mysqli_insert_id($conn);
	if($query){
		for ($i=1; $i<=$numberPic; $i++){
			if (isset($_FILES['pic-'.$i])){
			
				$file_name='test/'.basename($_FILES['pic-'.$i]['name']);
				$file_path=$_FILES['pic-'.$i]['tmp_name'];
				$upload_img = new Upload_img($file_name,$file_path, $id_product, $i);
				
			}
		}
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/produit.php?upload=true">';
	}else {
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/produit.php?upload=false">';
	}
}
?>
<div class="row">
    <div class="col-md-12">
        <h2>Ajouter un produit</h2>
    </div>
</div>
<?php
if(isset($_GET['upload'])){
	if($_GET['upload'] == "true"){
		echo "<br><div class='alert alert-success'>
			<strong>Le produit à étè bien ajouté</strong>
		</div>";
	}elseif($_GET['upload'] == "false"){
		echo "<br><div class='alert alert-danger'>
			<strong>Erreur servenu</strong>
		</div>";
	}
}
?>
                 <hr />
<div class="row">
    <div class="col-md-12">
	    <form method="post" enctype="multipart/form-data" class="form-horizontal custom-form">
			<input name="numberPic" type="hidden" id="numberPic" value="0"/>
			<input name="numberCat" type="hidden" id="numberCat" value="0"/>
            <div class="form-group">
                <div class="col-sm-2 label-column">
                    <label for="name-input-field" class="control-label"><strong>Nom de Produit*</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="text" name="nom" placeholder="Nom de Produit" class="form-control" />
                </div>
            </div>
			<div class="form-group">
                <div class="col-sm-2 label-column">
                    <label for="name-input-field" class="control-label"><strong>Keywords*</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="text" name="keywords" placeholder="keywords" class="form-control" />
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12 label-column">
                    <label for="repeat-pawssword-input-field" class="control-label"><strong>Description de Produit*</strong></label>
                </div>
                <div class="col-sm-12">
                    <textarea rows="20" cols="50" name="elm1" placeholder="Description de Produit" class="form-control input-lg textarea"></textarea>
                </div>
            </div>
			<div class="form-group">
                <div class="col-sm-2 label-column">
                    <label for="name-input-field" class="control-label"><strong>PRIX*</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="text" name="prix" placeholder="prix" class="form-control" />
                </div>
            </div>
			<div class="form-group">
                <div class="col-sm-2 label-column">
                    <label for="name-input-field" class="control-label"><strong>Catégorie*</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <select name="categorie"  class="form-control" >
					<?php
						$sql = "select * from category";
						$query = mysqli_query($conn, $sql);
						while($row = mysqli_fetch_array($query)){
					?>
						<option value="<?php echo $row['id_category']; ?>"><?php echo $row['category_name'];?></option>
					<?php
						}
					?>
					</select>
                </div>
            </div>
			<div id="dropzone" class="form-group">
				<div class="col-sm-12 label-column">
					<label class="control-label" for="email-input-field"><strong>L'image de Produit* </strong></label>
				</div>
			</div>
			
			<a class="btn btn-primary submit-button" name="" id="addPhoto"><i class="fa fa-plus"></i> Ajouter une photo </a><br><br>
            <button class="btn btn-primary submit-button" type="submit" name="enregistrer">Enregistrer </button>
        </form>
    </div>
</div>
<script>
$("#addPhoto").click(function(){
	var value = parseInt(document.getElementById('numberPic').value, 10);
	value++;
	if (value <= 16){
    
	document.getElementById("dropzone").innerHTML += 
	"<div id='photo-"+ value +"' class='col-sm-12 input-column'><input type='file' name='pic-"+ value +"'><a href='#' onclick='deleteP("+ value +")' class='btn btn-primary submit-button delete' id='Dphoto-"+ value +"'> delete</a></div>";
	document.getElementById('numberPic').value = value;
	}
});
function deleteP(val){
$("#photo-"+val).remove();
}
</script>
<?php include("footer.php"); ?>