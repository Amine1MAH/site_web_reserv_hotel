<?php include('header.php'); ?>
<div class="col-sm-1"></div>
<div class="col-sm-10">
	<div class="panel panel-default">
		<div class="panel-body">
		<h2>Details Commande</h2>
		<div>
		<?php
		$id_booking = valid_donnees($_GET['id_booking']);
		if(isset($_GET['id_booking']) && isset($_POST['update'])){
			
			$status = mysqli_real_escape_string($conn, $_POST['status']);
			$sql = "update booking set statu = $status where id_booking = '$id_booking'";
			$query = mysqli_query($conn, $sql);
			if($query){
				echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/booking_details.php?id_booking='.$id_booking.'">';
			}
		}
				$response = $db->prepare('select * from booking where id_booking= :id_booking');
				$response->execute(array('id_booking'=>$id_booking));
				$rows= $response->fetch();
				$id_billing = $rows['id_billing'];
				$response = $db->prepare('select * from billing where id_billing= :id_billing');
				$response->execute(array('id_billing'=>$id_billing));
				$row= $response->fetch();
		?>

			Nom & Prenom : <strong><?=$row['full_name']?></strong><br>
			Adresse : <strong><?=$row['address']?></strong><br>
			Ville : <strong><?=$row['city']?></strong><br>
			Code postal : <strong><?=$row['zip_code']?></strong><br>
			Pays : <strong><?=$row['country']?></strong><br>
			Telephone : <strong><?=$row['phone']?></strong><br>	
		</div>	
		<table class="table table-bordered table-striped col-sm-9">
		<thead>
		  <tr>
			<th>#</th>
			<th>Nom</th>
			<th>Prix</th>
			<th>Total</th>
		  </tr>
		</thead>
		<tbody>
		<tr>
			<td><a href="details.php?id=<?=$rows['id_product']?>"><img src="../<?=$product->get_image($rows['id_product'])?>" alt=" " class="img-responsive img-thumbnail" width="100px" /></a></td>
			<td><strong><?=$rows['start_date']?></strong></td>
			<td><strong><?=$rows['end_date']?></strong></td>
		  </tr>
		  </tbody>
		</table>
		<form method="post">
		  <select name="status">
		  <?php 
			$options = array(
							array(0, 1, 2),
							array("---------", "Confirmer", "Annuler")
						);
			$i=0;
			foreach ($options as $option) {
				$selected = ($option[0][$i] == $rows['statu']) ? 'selected' : ''; // Vérifie si l'option correspond à la valeur de la base de données
				echo '<option value="' . $option[1][$i] . '" ' . $selected . '>' . $option[1][$i] . '</option>';
				$i=$i+1;
			}
		  ?>
			<option value="0" />---------
			<option value="1" />Confirmer
			<option value="2" />Annuler
		  </select>
		  <input type="submit" name="update" value="Changer">
		</form>
		<a href="suprimer.php?id=<?=$id_booking?>&&table=booking&&page=booking.php"><button class="btn btn-danger"><strong>Suprimer</strong></button></a>
		</div>
	</div>
</div>