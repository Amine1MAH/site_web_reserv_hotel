<?php
include('../includes/db.php');
		$username=$_POST['username'];
		$password=md5($_POST['password']);
		
		$sql="SELECT * FROM admin WHERE username='$username' AND password='$password'";
		$query=mysqli_query($conn, $sql);
		$num=mysqli_num_rows($query);
		if($num==1){
			$_SESSION['username']=$username;
			$_SESSION['password']=$password;
			header("Location:index.php");
			}
			else {
					header("location:login.php");
				}
	
?>