<?
include("../includes/db.php");
function set_flash(){
	
}
function is_already_in_use($field, $value, $table,mysqli $conn){
	$sql="select id_user from $table where $field = '$value'";
	$query=mysqli_query($conn, $sql);
	$num=mysqli_num_rows($query);
	return $num;
}
function count_visitors(mysqli $conn){
	$sql="select ip from visitors";
    $query=mysqli_query($conn, $sql);
    $checkIp=mysqli_num_rows($query);
	return $checkIp;
}
function count_orders(mysqli $conn){
	$sql="select serial from orders where statu='0'";
    $query=mysqli_query($conn, $sql);
    $count_oders=mysqli_num_rows($query);
	return $count_oders;
}
function totale_orders(mysqli $conn){
	$sql="select serial from orders";
    $query=mysqli_query($conn, $sql);
    $totale_orders=mysqli_num_rows($query);
	return $totale_orders;
}
function count_messages(mysqli $conn){
	$sql="select id_message from messages where statu='0'";
    $query=mysqli_query($conn, $sql);
    $count_messages=mysqli_num_rows($query);
	return $count_messages;
}
function totale_messages(mysqli $conn){
	$sql="select id_message from messages";
    $query=mysqli_query($conn, $sql);
    $totale_messages=mysqli_num_rows($query);
	return $totale_messages;
}
function addtocart($pid,$q){
 if($pid<1 or $q<1) return;
 if(is_array($_SESSION['cart'])){
 if(product_exists($pid)) return;
 $max=count($_SESSION['cart']);
 $_SESSION['cart'][$max]['productid']=$pid;
 $_SESSION['cart'][$max]['qty']=$q;
 $_SESSION['productid']=$pid;
 }
 else{
 $_SESSION['cart']=array();
 $_SESSION['cart'][0]['productid']=$pid;
 $_SESSION['cart'][0]['qty']=$q;
 }
}
function product_exists($pid){
 $pid=intval($pid);
 $max=count($_SESSION['cart']);
 $flag=0;
 for($i=0;$i<$max;$i++){
 if($pid==$_SESSION['cart'][$i]['productid']){
$flag=1;
break;
 }
}
return $flag;
}
function get_product_name($pid, mysqli $conn){
  $result=mysqli_query($conn, "select name from products where serial=$pid");
  $row=mysqli_fetch_array($result);
  return $row['name'];
 }
function get_price($pid, mysqli $conn){
  $result=mysqli_query($conn, "select price from products where serial=$pid");
  $row=mysqli_fetch_array($result);
  return $row['price'];
 }
function remove_product($pid){
  $pid=intval($pid);
  $max=count($_SESSION['cart']);
  for($i=0;$i<$max;$i++){
 if($pid==$_SESSION['cart'][$i]['productid']){
    unset($_SESSION['cart'][$i]);
	unset($_SESSION['sum'][$pid]);
    break;
   }
  }
 $_SESSION['cart']=array_values($_SESSION['cart']);
 }
function get_order_total(){
  $max=count($_SESSION['cart']);
  $sum=0;
  for($i=0;$i<$max;$i++){
   $pid=$_SESSION['cart'][$i]['productid'];
   $q=$_SESSION['cart'][$i]['qty'];
   $price=get_price($pid);
   $sum+=$price*$q;
  }
  $_SESSION['sum'][$pid]=$sum;
  return $sum;
 }
function uniqidReal($lenght) {
    // uniqid gives 13 chars, but you could adjust it to your needs.
    if (function_exists("random_bytes")) {
        $bytes = random_bytes(ceil($lenght / 2));
    } elseif (function_exists("openssl_random_pseudo_bytes")) {
        $bytes = openssl_random_pseudo_bytes(ceil($lenght / 2));
    } else {
        throw new Exception("no cryptographically secure random function available");
    }
    return substr(bin2hex($bytes), 0, $lenght);
}

?>