<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/user.css">
    <link rel="stylesheet" href="../assets/css/Pretty-Registration-Form.css">
</head>

<body background="../img/lyon.jpg">
<br><br><br><div class="col-sm-2"></div>
<div class="col-sm-8 panel panel-default">
<div class="col-md-6 col-md-offset-2 panel-body">
    <form method="post" action="check.php" class="form-signin"><span class="reauth-email"> </span>
	    
        <center><h1>Admin </h1></center>
		<p>
            
        </p>
            <div class="form-group">
                <div class="col-sm-4 label-column">
                    <label for="name-input-field" class="control-label"><strong>Username</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="text" name="username" placeholder="Username" class="form-control" />
                </div>
            </div><br><br>
            <div class="form-group">
                <div class="col-sm-4 label-column">
                    <label for="email-input-field" class="control-label"><strong>Mot de passe</strong> </label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="password" name="password" placeholder="password" inputmode="password" class="form-control" />
                </div>
            </div><br><br><br><br>
        <button class="btn btn-primary submit-button" type="submit" name="connexion">Connexion </button>
    </form></div>
</div>
</body>
</html>