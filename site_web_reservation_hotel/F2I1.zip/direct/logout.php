<?php
session_start();

if(isset($_SESSION['username'])) {
	session_destroy();
	header("Location:/F2I/direct/login.php");
	
	}
	else {
		header("Location:/F2I/direct/login.php");
		
	}
?>