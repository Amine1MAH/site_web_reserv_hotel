<? include("../includes/db.php");

if(isset($_POST['enregistrer'])){
	$password_anc=$_POST['password_anc'];
	$password_1=$_POST['password_1'];
	$password_2=$_POST['password_2'];
    if($password_1==$password_2 and $password_anc==$_SESSION['password']){
		$pass=md5($password_1);
	$sql="UPDATE admin SET password='$pass' where id_admin =1";
	$query=mysql_query($sql);
	$_SESSION['username']=$pass;
	if($query){
	header("Location:/shopping/direct/parametre.php");
	$error="<p>mehdii</p>";
	
}else{
	$error="<p>error</p>";
}
	}else{
		$error="<p>error</p>";
	}
}
?>
<? include("header.php"); ?>
<div class="row">
    <div class="col-md-12">
        <h2>Messages</h2>
        <h5>Welcome Jhon Deo , Love to see you back. </h5> 
    </div>
</div>
                 <!-- /. ROW  -->
                 <hr />
<div class="row">
<div class="col-md-12">
        <form method="post" action="">
            <h1>Changer le Mot de Passe </h1>
			<?=$error?>
            <div class="form-group">
                <div class="col-sm-4 label-column">
                    <label for="password_anc" class="control-label"><strong>Mot de Passe</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="password" name="password_anc" placeholder="Ancien Mot de Passe " class="form-control" />
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-4 label-column">
                    <label for="password_1" class="control-label"><strong>Nouveau Mot de Passe</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="password" name="password_1" placeholder="Nouveau Mot de Passe" class="form-control" />
                </div>
            </div>
			<div class="form-group">
                <div class="col-sm-4 label-column">
                    <label for="password_2" class="control-label"><strong>Retapez le Mot de Passe</strong></label>
                </div>
                <div class="col-sm-6 input-column">
                    <input type="password" name="password_2" placeholder="Retapez le Mot de Passe" class="form-control" />
                </div>
            </div>
            <button class="btn btn-primary submit-button" type="submit" name="enregistrer">Enregistrer </button>
        </form>
    </div>
</div>
<? include("footer.php"); ?>