<?php
include("../includes/db.php");
include("../includes/config.php");
$page=trim($_GET['page']);
$table=trim($_GET['table']);
$id=intval($_GET['id']);
if($table=='products'){
	

$delete="delete from $table where id_product='$id'";
$query_delete=mysqli_query($conn, $delete);
$delete="delete from cat_product where id_product='$id'";
$query_delete=mysqli_query($conn, $delete);
$sql="select * from product_pic where id_product='$id'";
$query=mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($query)){
	$path = '../images/product_pic/'.$row['path'];
	unlink($path);
}
$delete="delete from product_pic where id_product='$id'";
$query_delete=mysqli_query($conn, $delete);
}elseif($table=='category'){
	$delete="delete from $table where id_category='$id'";
	$query_delete=mysqli_query($conn, $delete);
}
if($query_delete){
	echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'direct/'.$page.'">';
}
?>