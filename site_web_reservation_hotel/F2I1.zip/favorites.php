<?php
include("includes/db.php");
include("includes/Product.php");
include("includes/functions.php");
$data=1;
$dataQ=1;
if(isset($_POST['id']) && isset($_SESSION['id_user'])){
	$pid=intval(valid_donnees($_POST['id']));
	
	if(check_favorites($pid) == 0){
		$dataQ = check_favorites($pid);
		$response = $db->prepare('insert into favorites (id_user, id_product) values(:id_user, :id_product)');
		$response->execute(array('id_user'=>$_SESSION['id_user'], 'id_product'=>$pid));
		if($response){
			$data = 0;
		}
	}else{
		$response = $db->prepare('delete from favorites where id_user= :id_user and id_product= :id_product');
		$response->execute(array('id_user'=>$_SESSION['id_user'], 'id_product'=>$pid));
		if($response){
			$data = 2;
		}
	}
}
 	$output = array(
		'dataV' => $data,
		'dataQ' => $dataQ
	);
	echo json_encode($output);
 ?>