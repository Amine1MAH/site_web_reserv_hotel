<?php


$id=intval($_GET['id']);

if($_GET['id']){
	include('includes/db.php');
	$sql = "select picture from products where id_product='$id'";
	$query = mysqli_query($conn, $sql);
    $fetch = mysqli_fetch_array($query, MYSQLI_ASSOC);
	
	
	echo $fetch['picture'];
    
	
	}

	
	


?>