<?php include("header.phtml");
if($_POST['command']=='delete'){
 session_destroy();
 echo'<meta http-equiv="refresh" content="0; URL=http://localhost/electro/index.php">';
 }
?>
<script language="JavaScript"> 
function imprime_zone(titre, obj) 
{
// Définie la zone à imprimer
var zi = document.getElementById(obj).innerHTML;
// Ouvre une nouvelle fenetre
var f = window.open("", "ZoneImpr", "height=500, width=600,toolbar=0, menubar=0, scrollbars=1, resizable=1,status=0, location=0, left=10, top=10");
// Définit le Style de la page
f.document.body.style.color = '#000000';
f.document.body.style.backgroundColor = '#FFFFFF';
f.document.body.style.padding = "10px";
// Ajoute les Données
f.document.title = titre;
f.document.body.innerHTML += " " + zi + " ";
// Imprime et ferme la fenetre
f.window.print();
f.window.close();
// delete session
document.form1.command.value='delete';
document.form1.submit();
return true;
}
</script>
<div class="checkout">
	<div class="container">
	<center><form name="form1" method="post" action=""><input type="hidden" name="command" /><button onclick="imprime_zone('Commande', 'imprimer');" class="btn btn-primary">imprimer la commande</button></form></center><br><br>
	<div id="imprimer"><div class="col-sm-6">
    <div class="panel panel-warning">
        <div class="panel-heading">
            <h3 class="panel-title"><b> Les informations personnel </b></h3>
        </div>
        <div class="panel-body">
            <form name="form1" onsubmit="validate()" method="post">
                <input type="hidden" name="command" />
                <div class="col-sm-10 col-sm-offset-1">
                    <p class="col-sm-12"><b>Nom Complet : </b><?=$_SESSION['name']?></p><br><br>
                    <p class="col-sm-12"><b>address : </b><?=$_SESSION['address']?></p><br><br>
                    <p class="col-sm-12"><b>Telephone : </b><?=$_SESSION['phone']?></p><br><br>

                </div>
            </form>
        </div>
    </div>
</div>
<div class="col-sm-5 col-sm-offset-1">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title"><b> La facture </b></h3>
        </div>
        <div class="panel-body">
            <table class="table table-striped table-condensed table-hover">
            <?php
                echo '<tr bgcolor="#FFFFFF" style="font-weight:bold"><th> # </th><th> Produit </th><th> Prix </th><th> Quantité </th><th> Prix total </th>';
                $max=count($_SESSION['cart']);
                for($i=0;$i<$max;$i++){
                $pid=$_SESSION['cart'][$i]['productid'];
                $q=$_SESSION['cart'][$i]['qty'];
                $pname=get_product_name($pid);
                if($q==0) continue;
            ?>
                <tr bgcolor="#FFFFFF"><td scope="row"><?php echo $i+1?></td><td><?php
                echo $pname?></td>
                <td><?php echo get_price($pid)?>Dhs</td>
                <td><?php echo $q ;?></td>
                <td><?php echo get_price($pid)*$q ?>DHs</td>
            <?php
             }
            ?>
                <tr><td colspan="6"><b> total : <?php echo get_order_total()?>DHs</b></td></tr>
            </table>
        </div>
    </div>
	</div>
</div>
</div>
</div>
<? include'footer.phtml'?>