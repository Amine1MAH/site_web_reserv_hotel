<?php include"header.phtml"; ?>
<div id="booking" class="section">
    <div class="section-center">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-md-push-5">
                    <div class="booking-cta">
                        <h1>Réservez maintenant</h1>
                        <p>Explorez des logements uniques pour tous vos voyages. Réservez en toute simplicité et en toute confiance. 
						Profitez d'un service personnalisé et de tarifs compétitifs. 
						Découvrez de nouveaux lieux et créez des souvenirs inoubliables. 
						Bienvenue sur notre site de réservation, votre porte d'entrée vers des expériences de voyage extraordinaires.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-md-pull-7">
                    <div class="booking-form">
                        <form method="get" action="booking.php">
                            <div class="form-group">
                                <span class="form-label">Votre Destination</span>
                                <input name="city" class="form-control" type="text" placeholder="Enter Votre Destination" required>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <span class="form-label">Date d'arrivée</span>
                                        <input id="date_debut" name="date_debut" class="form-control" type="date" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <span class="form-label">Date de départ</span>
                                        <input id="date_fin" name="date_fin" class="form-control" type="date" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
							  <div class="col-sm-6">
								<div class="form-group">
								  <span class="form-label">Adulte(s)</span>
								  <div>
									<button class="col-sm-2" type="button" onclick="decreaseValue('adults')">-</button>
									<input class="col-sm-6" id="adults" name="adults" class="form-control" type="text" value="1" required>
									<button class="col-sm-2" type="button" onclick="increaseValue('adults')">+</button>
								  </div>
								</div>
							  </div>
							  <div class="col-sm-6">
								<div class="form-group">
								  <span class="form-label">Enfant(s)</span>
								  <div>
									<button class="col-sm-2" type="button" onclick="decreaseValue('children')">-</button>
									<input class="col-sm-6" id="children" name="children" class="form-control" type="text" value="0" required>
									<button class="col-sm-2" type="button" onclick="increaseValue('children')">+</button>
								  </div>
								</div>
							  </div>
							</div>
							<div class="form-group">
                                        <span class="form-label">Type d'hébergement</span>
                                        <select name="category" class="form-control">
											<option value="all">toutes les catégories</option>
											<?php
												$sql_cat="select * from category";
												$query_cat=mysqli_query($conn, $sql_cat);
												while($row=mysqli_fetch_array($query_cat)){
													echo "<option value='".$row['id_category']."'>".$row['category_name']."</option>";
												}
											
											?>
										</select>
                                        <span class="select-arrow"></span>
                                    </div>
                            <div class="form-btn">
                                <button class="submit-btn">Rechercher</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php include'footer.phtml';?>