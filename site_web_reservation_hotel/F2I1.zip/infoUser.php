<?php 
	include("header.phtml");
	
	if(!isset($_SESSION['id_user'])){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login">';
	}
if(isset($_POST['update']) && !empty($_POST['email']) && !empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['phone']) && !empty($_POST['sex'])){
	
	if($users->find_info('email', $_POST['email'], $id_user) != $_POST['email']){
		if($users->find_info('phone', $_POST['phone'], $id_user) != $_POST['phone']){
			$first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
			$last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
			$phone = mysqli_real_escape_string($conn, $_POST['phone']);
			$email = mysqli_real_escape_string($conn, $_POST['email']);
			$sex = mysqli_real_escape_string($conn, $_POST['sex']);
			
			$sql = "update users set 
					first_name = '$first_name', last_name = '$last_name', phone = '$phone', email = '$email', gender = '$sex'
					where id_user = '$id_user'";
			$query = mysqli_query($conn, $sql);
			if($query){
				echo"<meta http-equiv='refresh' content='0; URL=".$url_site."infoUser.php?update=true'>";
			}else{
				echo"<meta http-equiv='refresh' content='0; URL=".$url_site."infoUser.php?update=false'>";
			}
		}else{
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."infoUser.php?update=falsePhone'>";
		}
	}
	else{
		echo"<meta http-equiv='refresh' content='0; URL=".$url_site."infoUser.php?update=falseMail'>";
	}
}
?>

<div class="checkout">
	<div class="container">
		<div class="new_arrivals">
		   <h3>Ajouter <span>une adresse</span></h3>
		</div>
		<?php
		if(isset($_GET['add'])){
			if($_GET['add'] == "true"){
				echo "<br><div class='alert alert-success'>
					<strong>Votre adresse a ete bien ajouté</strong>
				</div>";
			}elseif($_GET['add'] == "false"){
				echo "<br><div class='alert alert-danger'>
					<strong>Erreur servenu</strong>
				</div>";
			}
		}
		?>
		<div class="col-sm-6 col-sm-offset-3">
			<div class="panel panel-warning">
				<div class="panel-body">
				  <form method="post" name="form2">
					<table>
						
					<?php
					$response = $db->prepare('select * from users where id_user= :id_user');
					$response->execute(array('id_user'=>$id_user));
						$row = $response->fetch();
						
						echo "
						<tr>
							<td>Prénom : </td><td><input name='first_name' id='first_name' class='infoU inputModi' type='text' value='".strip_tags($row['first_name'])."' disabled></td>
						</tr>
						<tr>
							<td>Nom : </td><td><input name='last_name' id='last_name' class='infoU inputModi' type='text' value='".strip_tags($row['last_name'])."' disabled></td>
						</tr>
						<tr>
							<td>Email : </td><td><input name='email' id='email' class='infoU inputModi' type='text' value='".strip_tags($row['email'])."' disabled></td>
						</tr>
						<tr>
							<td>Téléphone : </td><td><input name='phone' id='phone' class='infoU inputModi' type='text' value='".strip_tags($row['phone'])."' disabled></td>
						</tr>
						<tr>
							<td>Sexe :</td><td>";
						if($row['gender']=='male'){
						echo"<input name='sex' id='sex' class='infoU inputModi' type='radio' value='male' checked disabled> Homme
						<input name='sex' id='sex' class='infoU inputModi' type='radio' value='female' disabled> Femme";
						}else{
							echo"<input name='sex' id='sex' class='infoU inputModi' type='radio' value='male' disabled> Homme
							<input name='sex' id='sex' class='infoU inputModi' type='radio' value='female' checked disabled> Femme";
						}
						echo '</td>
						</tr>'
						?>
						<tr>
							<td colspan='2'>
								<button type='submit' name='update' class='btn btn-primary' id='update-info' style='display: none;'>Modifier</button>
								<a class='btn btn-primary' id='edit-info' onclick='infoUpdate()'>Modifier</a>
								<a class='btn btn-danger' id='cancel-info' onclick='infoCancel()' style='display: none;'>Annuler</a><hr>
								<a href="<?=$url_site?>ChangePassword.php" id='edit-info'>Changer le mot de passe</a>
							</td>
						</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="application/x-javascript">
var i, tabcontent, first_name, last_name,email,phone,sex;
function infoUpdate(){
	
	tabcontent = document.getElementsByClassName('infoU');
	
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].disabled = false;
		tabcontent[i].style.border = '1px black solid';
	}
	
	first_name = document.getElementById('first_name').value;
	last_name = document.getElementById('last_name').value;
	email = document.getElementById('email').value;
	phone = document.getElementById('phone').value;
	sex = document.getElementById('sex').value;
	document.getElementById('update-info').style.display = 'inline';
	document.getElementById('cancel-info').style.display = 'inline';
	document.getElementById('edit-info').style.display = 'none';
}
function infoCancel(){
	tabcontent = document.getElementsByClassName('infoU');
	
	document.getElementById('first_name').value = first_name;
	document.getElementById('last_name').value = last_name;
	document.getElementById('email').value = email;
	document.getElementById('phone').value = phone;
	document.getElementById('sex').checked = sex;
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].disabled = true;
		tabcontent[i].style.border = '0px';
	}
	document.getElementById('cancel-info').style.display = 'none';
	document.getElementById('update-info').style.display = 'none';
	document.getElementById('edit-info').style.display = 'inline';
}
function update(id_address){
	document.form1.id_address.value=id_address;
	document.form1.submit();
}
</script>
<?php include"footer.phtml"; ?>