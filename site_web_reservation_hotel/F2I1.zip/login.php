<?php include"header.phtml";
$msg="";
if(isset($_SESSION['id_user'])){
	echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
}
if(isset($_GET['p'])){
	$page=$_GET['p'].".php";
}else{
	$page="index.php";
}
//On génére un jeton totalement unique
$tokenD = md5(uniqid(rand(), true));
//Et on le stocke
$_SESSION['tokenD'] = $tokenD;
//On enregistre aussi le timestamp correspondant au moment de la création du token
$_SESSION['token_timeD'] = time();
// Login in to c
$errors=[];
if(isset($_POST['login'])){
	echo "3";
	$email=valid_donnees($_POST['email']);
	$password=valid_donnees(md5($_POST['password']));
	$response = $db->prepare('select * from users where email= :email and password= :password');
	$response->execute(array('email'=>$email,'password'=>$password));
	if($response){
		echo "4";
		if($response->rowCount() == 1){
			echo "5";
			$row=$response->fetch();
			$_SESSION['id_user'] = $row['id_user'];
			echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
			}else{
				$errors[]="Votre adress email ou le mot de passe est incorrecte";
			}
		}
	}else if(isset($_POST['register'])){
		if(!empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['gender']) && !empty($_POST['email_reg']) && !empty($_POST['password_reg']) && !empty($_POST['password_reg1'])){
			
			$first_name=valid_donnees($_POST['first_name']);
			$last_name=valid_donnees($_POST['last_name']);
			$email=valid_donnees($_POST['email_reg']);
			$password=valid_donnees($_POST['password_reg']);
			$password1=valid_donnees($_POST['password_reg1']);
			$gender=valid_donnees($_POST['gender']);
			$phone=valid_donnees($_POST['phone']);
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$errors[]="Adress email invalide!";
			}
			if(mb_strlen($password) <= 8){
				$errors[]="Mot de passe trop court! (Minimum 8 caractères)";
			}else{
				if($password != $password1){
				$errors[]="Les deux mots de passe ne concordent pas!";
				}
			}
			if(is_already_in_use('email', $email, 'users')){
				$errors[]="Adresse E-mail déjà utilisé!";
			}
			if(count($errors) == 0){
				$pass=md5($password);
				$response = $db->prepare('insert into users (first_name, last_name, email, password, phone, gender, status) values(:first_name, :last_name, :email, :password,:phone, :gender,1)');
				$response->execute(array('first_name'=>$first_name, 'last_name'=>$last_name, 'email'=>$email, 'password'=>$pass, 'phone'=>$phone, 'gender'=>$gender));
					if($response){
						$_SESSION['id_user'] = $db->lastInsertId();
						ob_start();
						$token=sha1($email.$pass);
						$subject = $nom_site." - Confirmation d'inscription";
						$from = 'contact@atypikhouse.fr'; 
						$to = $email; 
						$fromName = 'ATYPIKHOUSE'; 
						 
						$htmlContent="<!doctype html>
						<html lang='fr'>
						  <head>
							<meta charset='utf-8'>
							<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
							<style>
								.content{
								width:80%;
								background:white;
								margin-left:10%;
								}
								.header{
								width:100%;
								height:20px;
								background:#028EE6;
								}
								.footer{
								width:100%;
								height:50px;
								background:black;
								font-size:15px;
								color:white;
								}
								table{
								border:3px solid black;
								border-spacing: 0;
								}
								td,th{
								border:1px solid black;
								padding:5px;
								}
								button{
								border:1px solid #028EE6;
								padding:20px;
								background:#028EE6;
								font-size:20px;
								color:white;
								}
								.body{
								padding:50px;
								font-size:15px;
								}
								.bod{
								padding:0;
								background:#F3F3F3;
								}
								@media (max-width: 768px) {
									.content{
									width:100%;
									margin-left:0;
									}
								}
							</style>
						  </head>
						  <body>
						  <div class='bod'>
							<div class='content'>
								<div class='header'></div>
								<div class='body'>
								<center><img src='http://f2i-dev15-imb.fr/images/logo.jpg'></center>
								<h2>Confirmation d'inscription</h2>
								<p><strong>Bonjour ".$first_name.",</strong><br>
								Merci pour inscrit sur notre site ATYPIKHOUSE</p>
								<br><br>
								</div>
								<div class='footer'><br><center>© 2023 . Tous les droits reserver à ATYPIKHOUSE</center></div>
							</div>
							</div>
							</body>
						</html>";
						 
						// Set content-type header for sending HTML email 
						$headers = "MIME-Version: 1.0" . "\r\n"; 
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
						 
						// Additional headers 
						$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
						// Send email 
						if(mail($to, $subject, $htmlContent, $headers)){ 
							echo 'Email has sent successfully.'; 
						}else{ 
						   echo 'Email sending failed.'; 
						}
						echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
					}
			}
		}else{
				$errors[]="Veuillez SVP remplir tous les champs";
			}
} 
?>

	<div class="container">
		<?=$msg?>
		<?php
		if(isset($errors) && count($errors)!= 0){
		echo"<div class='alert alert-danger'><strong>";
         foreach($errors as $errors){
		echo $errors."<br>";
	    }
        echo"</strong></div>";
	    }
		if(isset($_GET['PUpdate'])){
			if($_GET['PUpdate'] == "true"){
				echo "<br><div class='alert alert-success'>
					<strong>Votre mot de passe a bien été changé.</strong>
				</div>";
			}
		}
		?>
		<div class="row justify-content-center">
			<div class="col-md-12 col-xl-6">
				<h1 class="text-center font-weight-bold text-primary">Connectez-vous</h1>
				<hr class="bg-light">
				<form method="post" action="" id="form-box" class="p-2">
				<input type="hidden" name="tokenD" value="<?=$_SESSION['tokenD']?>" />
					<div class="form-group">
						<span class="form-label">Email :</span>
						<input class="form-control" name="email" type="text" placeholder="Email" required="">
					</div>
					<div class="form-group">
						<span class="form-label">Mot de passe :</span>
						<input class="form-control" name="password" type="password" placeholder="Mot de passe" required="">
						<a href="<?=$url_site?>resetPassword.php">Mot de passe oublié ?</a>
					</div>
					<div class="form-group">
						<input class="" type="checkbox" id="brand" value="">
						<span class="form-label">Souviens moi.</span>
					</div>
					<div class="form-btn">
						<input class="submit-btn" name="login" type="submit" value="Se connecter">
					</div>
				</form>
			</div>
			<div class="col-md-12 col-xl-6">
			<div class="row justify-content-center">
				<h1 class="text-center font-weight-bold text-primary">Inscrivez-vous</h1>
				<hr class="bg-light">
				<form method="post" action="" id="form-box" class="p-2">
					<div class="form-group">
						<span class="form-label">Nom :</span>
						<input class="form-control" name="last_name" type="text" placeholder="Nom" required="">	
					</div>
					<div class="form-group">
						<span class="form-label">Prenom :</span>
						<input class="form-control" name="first_name" type="text" placeholder="Prenom" required="">	
					</div>
					<div class="form-group">
						<span class="form-label">Sex :</span>
						<input class="" name="gender" type="radio"  value="male"> Homme 
						<input class="" name="gender" type="radio"  value="female"> Femme
					</div>
					<div class="form-group">
						<span class="form-label">Email :</span>
						<input class="form-control" name="email_reg" type="text" placeholder="Email" required="">	
					</div>
					<div class="form-group">
						<span class="form-label">Numero de telephone :</span>
						<input class="form-control" name="phone" type="text" placeholder="Numero de telephone" required="">	
					</div>
					<div class="form-group">
						<span class="form-label">Mot de passe :</span>
						<input class="form-control" name="password_reg" type="password" placeholder="Mot de passe" required="">
						
					</div>
					<div class="form-group">
						<span class="form-label">Retapez le mot de passe :</span>
						<input class="form-control" name="password_reg1" type="password" placeholder="Retapez le mot de passe" required="">
						
					</div>
					<div class="form-btn">
						<input class="submit-btn" name="register" type="submit" value="S'INSCRIRE">
					</div>
					
				</form>
				</div>
				<div class="row justify-content-center">
					<p>En vous s'inscrire, vous acceptez nos <a href="#">Conditions Générales</a> et notre <a href="#">Politique de Confidentialité</a></p>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
<?php include"footer.phtml"?>