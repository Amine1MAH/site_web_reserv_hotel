<?php
session_start();
include'includes/config.php';
if(isset($_SESSION['id_user'])) {
	unset($_SESSION['id_user']);
	header("Location:".$url_site."login.php");
	
	}
	else {
		header("Location:".$url_site."login.php");
	}
?>