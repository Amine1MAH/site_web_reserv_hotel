<?
include"header.phtml";
echo'<div class="alert alert-success">
  <strong>Merci pour votre confiance !</strong> votre commande est prête à être expédiée.
</div><br><br><br><br>';
if(isset($_SESSION['content'])){
	$subject = $nom_site." - Details de commande";
	$headers = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$message ='<!doctype html>
				<html lang="fr">
				  <head>
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"></head>
				  <body bgcolor="#F3F3F3">
				    <h3>CDetails de commande!</h3>
	                <p><b>Bonjour '.$full_name.' </b></p>
	                <p>merci pour votre confiance votre commande est prête à être expédiée</p>';
	$message .= $_SESSION['content'];
	$message .='
			  </body>
			</html>';
	mail($email, $subject, $headers, $message);
    unset($_SESSION['cart']);
	echo'<meta http-equiv="refresh" content="10; URL='.$url_site.'users/commandes.php">';
}
include"footer.phtml";
?>