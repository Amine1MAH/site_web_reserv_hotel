<?php


use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;

require 'includes/config.php';
require 'includes/configPayPal.php';

include("includes/db.php");
include("includes/functions.php");
include("includes/function.php");
include"includes/Product.php";
include"includes/Carte.php";
include"includes/users.php";

$payer = new Payer();
$payer->setPaymentMethod("paypal");

$id_user = $_SESSION['id_user'];
if(isset($_GET['Address']) && isset($_GET['date_debut']) && isset($_GET['date_fin'])){
	
	// Convertir les dates en timestamps
	$timestamp1 = strtotime($_GET['date_debut']);
	$timestamp2 = strtotime($_GET['date_fin']);

	// Calculer la différence en secondes
	$diff_seconds = $timestamp2 - $timestamp1;

	// Convertir la différence en jours
	$count_day = floor($diff_seconds / (60 * 60 * 24));
	$pid=$_GET['id'];
	$pname=$product->get_product_name($pid);
	$price = $product->get_price($pid);
	$total = $price*$count_day;
	$item[0] = new Item();
	$item[0]->setName($pname)
				->setCurrency('EUR')
				->setQuantity($count_day)
				->setSku($pid) // Similar to `item_number` in Classic API
				->setPrice($price*0.8);
}else{
	exit;
}


$itemList = new ItemList();
$itemList->setItems($item);

$details = new Details();
$details->setShipping(0)
    ->setTax($total*0.2)
    ->setSubtotal($total*0.8);
	
$amount = new Amount();
$amount->setCurrency("EUR")
    ->setTotal($total)
    ->setDetails($details);
	
$transaction = new Transaction();
$transaction->setAmount($amount)
    ->setItemList($itemList)
    ->setDescription("Payment description")
    ->setInvoiceNumber(uniqid());
	
$redirectUrls = new RedirectUrls();
$redirectUrls->setReturnUrl($paypalConfig['return_url'])
    ->setCancelUrl($paypalConfig['cancel_url']);
	
$payment = new Payment();
$payment->setIntent("sale")
    ->setPayer($payer)
    ->setRedirectUrls($redirectUrls)
    ->setTransactions(array($transaction));

$request = clone $payment;



try {
    $payment->create($apiContext);
} catch (Exception $ex) {
	echo($request." ".$ex);
    exit(1);
}

$approvalUrl = $payment->getApprovalLink();
header('location:' . $payment->getApprovalLink());

return $payment;

?>