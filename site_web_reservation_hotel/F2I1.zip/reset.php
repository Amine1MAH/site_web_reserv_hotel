<?php 
	include("header.phtml");
	
	if(isset($_SESSION['id_user'])){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
	}
	if(isset($_POST['enregistrer'])){
		$email = $_GET['email'];
		$id_user = $users->get_idUser("email", $email);
		$token=$_GET['token'];
		$password= $users->get_info("password", $id_user);
		$password_1=$_POST['password_1'];
		$password_2=$_POST['password_2'];
		if($password_1==$password_2){
			if($token==sha1($email.$password)){
				$pass=md5($password_1);
				$response = $db->prepare('UPDATE users SET password= :pass where id_user = :id_user');
				$response->execute(array('pass'=>$pass, 'id_user'=>$id_user));
				if($response){
					echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login.php?PUpdate=true">';
				}else{
					echo"<meta http-equiv='refresh' content='0; URL=".$url_site."reset.php?email=".$email."&token=".$token."&update=false'>";
				}
			}else{
				echo"<meta http-equiv='refresh' content='0; URL=".$url_site."reset.php?email=".$email."&token=".$token."&update=TFalse'>";
			}
		}else{
			echo"<meta http-equiv='refresh' content='0; URL=".$url_site."reset.php?email=".$email."&token=".$token."&update=PFalse'>";
		}
	}

?>
<div class="container">
	<br><br><div class="row">

<div class="new_arrivals">
   <h3><span>Mot de passe </span>oublier</h3>
</div>
<?php
		if(isset($_GET['update'])){
			if($_GET['update'] == "true"){
				echo "<br><div class='alert alert-success'>
					<strong>Votre mot de passe a bien été changé.</strong>
				</div>";
			}elseif($_GET['update'] == "false"){
				echo "<br><div class='alert alert-danger'>
					<strong>Erreur serveur, veuillez réessayer ultérieurement.</strong>
				</div>";
			}elseif($_GET['update'] == "PFalse"){
				echo "<br><div class='alert alert-danger'>
					<strong>Vos deux mots de passe ne sont pas identiques.</strong>
				</div>";
			}elseif($_GET['update'] == "TFalse"){
				echo "<br><div class='alert alert-danger'>
					<strong>Le Token est incorrect.</strong>
				</div>";
			}
		}
		?>
<div class="col-sm-6 col-sm-offset-3">
    <div class="panel panel-warning">
        <div class="panel-body">
		
            <form method="post" action="">
				<div class="form-group">
					<div class="label-column">
						<label for="password_1" class="control-label"><strong>Nouveau Mot de Passe</strong></label>
					</div>
					<div class="input-column">
						<input type="password" name="password_1" placeholder="Nouveau Mot de Passe" class="form-control" />
					</div>
				</div>
				<div class="form-group">
					<div class="label-column">
						<label for="password_2" class="control-label"><strong>Retapez le Mot de Passe</strong></label>
					</div>
					<div class="input-column">
						<input type="password" name="password_2" placeholder="Retapez le Mot de Passe" class="form-control" />
					</div>
				</div><br>
				<div class="form-group">
				<button class="btn btn-primary submit-button" type="submit" name="enregistrer">Enregistrer </button>
				</div>
			</form>
        </div>
    </div>
</div>

</div>
</div>
<?php include"footer.phtml"; ?>