<?php 
	include("header.phtml");
	
	if(isset($_SESSION['id_user'])){
		echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
	}

?>
<div class="container">
	<br><br><div class="row">
	<?php
	if(isset($_GET['send'])){
		if($_GET['send'] == "true"){
			echo "<br><div class='alert alert-success'>
				<strong>Un e-mail a été envoyé à votre adresse e-mail associée à votre compte pour réinitialiser votre mot de passe. Veuillez vérifier votre boîte de réception.</strong>
			</div>";
		}elseif($_GET['send'] == "false"){
			echo "<br><div class='alert alert-danger'>
				<strong>Erreur serveur, veuillez réessayer ultérieurement.</strong>
			</div>";
		}
	}
	?>

<div class="new_arrivals">
   <h3><span>Mot de passe </span>oublier</h3>
</div>
<div class="col-sm-6 col-sm-offset-3">
    <div class="panel panel-warning">
        <div class="panel-body">
		
            <form method="post" action="">
                <div align="center"  class="col-sm-10 col-sm-offset-1">
                    <p class="col-sm-12">Adress mail</p><br><br>
                    <p class="col-sm-12"><input class="form-control" type="text" name="mail" placeholder=" Adress mail " /></p><br><br>
					<p><input name="submit" class="btn btn-primary" type="submit" value="Réinitialisation le mot de passe" /></p>
                </div>
            </form>
        </div>
    </div>
</div>

</div>
</div>
<?php
if(isset($_POST['submit']) && !empty($_POST['mail'])){
	ob_start();
	$email = $_POST['mail']; 
	$id_user = $users->get_idUser("email", $email);
	$password = $users->get_info("password", $id_user);
	$token=sha1($email.$password);
	$subject = "Réinitialisation du mot de passe";
	$from = 'contact@atypikhouse.fr'; 
	$to = $email; 
	$fromName = $nom_site; 
	 
	$htmlContent="<!doctype html>
	<html lang='fr'>
	  <head>
		<meta charset='utf-8'>
		<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
		<style>
			.content{
			width:80%;
			background:white;
			margin-left:10%;
			}
			.header{
			width:100%;
			height:20px;
			background:#028EE6;
			}
			.footer{
			width:100%;
			height:50px;
			background:black;
			font-size:15px;
			color:white;
			}
			table{
			border:3px solid black;
			border-spacing: 0;
			}
			td,th{
			border:1px solid black;
			padding:5px;
			}
			button{
			border:1px solid #028EE6;
			padding:20px;
			background:#028EE6;
			font-size:20px;
			color:white;
			}
			.body{
			padding:50px;
			font-size:15px;
			}
			.bod{
			padding:0;
			background:#F3F3F3;
			}
			@media (max-width: 768px) {
				.content{
				width:100%;
				margin-left:0;
				}
			}
		</style>
	  </head>
	  <body>
	  <div class='bod'>
		<div class='content'>
			<div class='header'></div>
			<div class='body'>
			<center><img src='http://f2i-dev15-imb.fr/images/logo3.png'></center>
			<h2>Réinitialisation du mot de passe</h2>
			<p><strong>Bonjour ,</strong><br>
			Vous avez récemment fait une demande de réinitialisation du mot de passe de votre compte</p>
			<br>
			Pour terminer le processus veuillez cliquer sur le lien ou copie et coller sur le navigateur ci-dessous :<br>
			<a href='".$url_site."reset.php?email=".$email."&token=".$token."'></a>
			<br>".$url_site."reset.php?email=".$email."&token=".$token."
			</div>
			<div class='footer'><br><center>© 2023 . Tous les droits reserver à ATYPIKHOUSE</center></div>
		</div>
		</div>
		</body>
	</html>";
	 
	// Set content-type header for sending HTML email 
	$headers = "MIME-Version: 1.0" . "\r\n"; 
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
	 
	// Additional headers 
	$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
	// Send email 
	if(mail($to, $subject, $htmlContent, $headers)){ 
		echo"<meta http-equiv='refresh' content='0; URL=".$url_site."resetPassword.php?send=true'>"; 
	}else{ 
	   echo"<meta http-equiv='refresh' content='0; URL=".$url_site."resetPassword.php?send=false'>"; 
	}
}
?>
<?php include"footer.phtml"; ?>