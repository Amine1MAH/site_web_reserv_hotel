<?php

use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;

require 'includes/config.php';
require 'includes/configPayPal.php';
include"includes/users.php";
include("includes/db.php");
include("includes/functions.php");
include("includes/function.php");
include"includes/Product.php";
include"includes/Carte.php";


if (empty($_GET['paymentId']) || empty($_GET['PayerID'])) {
    throw new Exception('The response is missing the paymentId and PayerID');
}

$paymentId = $_GET['paymentId'];
$payment = Payment::get($paymentId, $apiContext);

$execution = new PaymentExecution();
$execution->setPayerId($_GET['PayerID']);

try {
    // Take the payment
    $payment->execute($execution, $apiContext);

    try {
        

        $payment = Payment::get($paymentId, $apiContext);
		$count = count($payment->transactions[0]->item_list->items);
		$json = $payment->transactions[0]->item_list->items[0]->sku;
		$transaction_id = $payment->getId();
		$payment_amount = $payment->transactions[0]->amount->total;
		$currency_code = $payment->transactions[0]->amount->currency;
		$payment_status = $payment->getState();
		$invoice_id = $payment->transactions[0]->invoice_number;
		$description = $payment->transactions[0]->description;
        if ($payment_status == 'approved') {
			
            // Payment successfully added, redirect to the payment complete page.
			$id_booking=booking($_SESSION['name'], $_SESSION['address'], $_SESSION['zip_code'], $_SESSION['city'], $_SESSION['mail'], $_SESSION['phone'], $_SESSION['id_product'], $_SESSION['id_user'], $_SESSION['start_date'], $_SESSION['end_date'], $_SESSION['nb_adults'], $_SESSION['nb_children'],"PayPal");
			echo $id_booking;
			if($id_booking != false){	
				$response = $db->prepare('INSERT INTO payments (id_booking,transaction_id, payment_amount,currency_code, payment_status, invoice_id, createdtime) 
				VALUES(:id_booking, :transaction_id, :payment_amount, :currency_code, :payment_status, :invoice_id, "'.date("Y-m-d H:i:s").'")');
				$response->execute(array('id_booking'=>$id_booking, 'transaction_id'=>$transaction_id, 'payment_amount'=>$payment_amount, 'currency_code'=>$currency_code, 'payment_status'=>$payment_status, 'invoice_id'=>$invoice_id));
				header("location:".$url_site."SuccessOrder.php?payid=$id_booking");
				exit(1);
			}
			
        } else {
            // Payment failed
			header($url_site."FailedOrder.php");
             exit(1);
        }

    } catch (Exception $e) {
        // Failed to retrieve payment from PayPal
		// Payment failed
			header($url_site."FailedOrder.php");
             exit(1);
    }

} catch (Exception $e) {
    // Failed to take payment

}
