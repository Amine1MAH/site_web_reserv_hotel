<?php

 
$htmlContent='<!doctype html>
<html lang="fr">
  <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<style>
	    .content{
		width:80%;
		background:white;
		margin-left:10%;
		}
		.header{
		width:100%;
		height:20px;
		background:#028EE6;
		}
		.footer{
		width:100%;
		height:50px;
		background:black;
		font-size:15px;
		color:white;
		}
		table{
		border:3px solid black;
		border-spacing: 0;
		}
		td,th{
		border:1px solid black;
		padding:5px;
		}
		button{
		border:1px solid #028EE6;
		padding:20px;
		background:#028EE6;
		font-size:20px;
		color:white;
		}
		.body{
		padding:50px;
		font-size:15px;
		}
		.bod{
		padding:0;
		background:#F3F3F3;
		}
		@media (max-width: 768px) {
			.content{
			width:100%;
			margin-left:0;
			}
        }
	</style>
  </head>
  <body>
  <div class="bod">
    <div class="content">
	    <div class="header"></div>
		<div class="body">
		<center><img src="https://www.5coins.fr/images/logo.jpg"></center>
		<h2>Activation de votre compte!</h2>
		<p><strong>Merci <?=$full_name?>  pour inscrit sur nos site shoppingow</p>
		<p><strong>Pour activer votre compte, veuillez cliquer sur ce lien ci-dessous :</strong></p><br><br>
		<br><br>
		<center><a href="5coins.fr/activation.php">Cliquer ici pour activer votre compte</a></center><br><br>
		</div>
		<div class="footer"><br><center>© 2017 . Tous les droits reserver a shoppingow</center></div>
	</div>
	</div>
	</body>
</html>';

if(isset($_POST['submit'])){
	$arr = explode("\r\n", trim($_POST['mailist']));
	$success_send = "";
	$failed_send = "";
	$j=0;
	$k=0;
	for ($i = 0; $i < count($arr); $i++) {
	   $to = $arr[$i]; 
		$from = 'contact@5coins.fr'; 
		$fromName = '5coins'; 
		 
		$subject = $_POST['sujet']; 
		// Set content-type header for sending HTML email 
		$headers = "MIME-Version: 1.0" . "\r\n"; 
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
		 
		// Additional headers 
		$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
		 
		// Send email 
		
		if(mail($to, $subject, $htmlContent, $headers)){ 
			$success_send = $to.'<br>'; 
			$j++;
		}else{ 
		   $failed_send = $to.'<br>'; 
		   $k++;
		}
		
	}
	
}

 ?>