<html>
<head>
	<title>kkkkkkkkkkkk</title>  
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
	
	
	#myProgress {
	  width: 100%;
	  background-color: grey;
	}

	#myBar {
	  width: 1%;
	  height: 30px;
	  background-color: #028EE6;
	}
	</style>
 </head>
<body>
	<div class="container">
		<div class="panel panel-default  col-sm-4">
			<div class="panel-heading">
				<h3 class="panel-title">Enter Data</h3>
			</div>
			<div class="panel-body">
				<form method="post" id="sample_form">
					<div class="form-group">
						<label>Sujet</label>
						<input type="text" name="sujet" id="sujet" class="form-control" />
						<span id="first_name_error" class="text-danger"></span>
					</div>
					<div class="form-group">
						<label>liste mail liste :</label>
						<textarea name="mailist" id="mailist" cols="40" rows="10"  class="form-control" ></textarea>
						<span id="first_name_error" class="text-danger"></span>
					</div>
					<div class="form-group" align="center">
					<input class="btn btn-primary"  id="send" type="submit" name="submit" value="Envoyer">
					</div>
				</form>
			</div>
		</div>
		<div class="panel panel-success  col-sm-4">
			<div class="panel-heading">
				<h3 class="panel-title">envoyé : <?php if(isset($j)){ echo $j; } ?></h3>
			</div>
			<div class="panel-body">
				<?php 
					if(isset($success_send)){
						echo $success_send;
					}
				?>
			</div>
		</div>
		<div class="panel panel-danger  col-sm-4">
			<div class="panel-heading">
				<h3 class="panel-title">Non envoyé : <?php if(isset($k)){ echo $k; } ?></h3>
			</div>
			<div class="panel-body">
				<?php 
					if(isset($failed_send)){
						echo $failed_send;
					}
				?>
			</div>
		</div>
		<div class="progress">
			<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="">
		</div>
		
	</div>
	<script>
		 $(document).ready(function(){
		  $('#sample_form').on('submit', function(event){
		   event.preventDefault();
			$.ajax({
			 url:"process.php",
			 method:"POST",
			 data:$(this).serialize(),
			 beforeSend:function()
			 {
			  $('#save').attr('disabled', 'disabled');
			  $('#process').css('display', 'block');
			 },
			 success:function(data)
			 {
			  var percentage = 0;

			  var timer = setInterval(function(){
			   percentage = percentage + 20;
			   progress_bar_process(percentage, timer);
			  }, 1000);
			 }
			})
		  });

		  function progress_bar_process(percentage, timer)
		  {
		   $('.progress-bar').css('width', percentage + '%');
		   if(percentage > 100)
		   {
			clearInterval(timer);
			$('#sample_form')[0].reset();
			$('#process').css('display', 'none');
			$('.progress-bar').css('width', '0%');
			$('#save').attr('disabled', false);
			$('#success_message').html("<div class='alert alert-success'>Data Saved</div>");
			setTimeout(function(){
			 $('#success_message').html('');
			}, 5000);
		   }
		  }

		 });
	</script>
</body>
</html>
