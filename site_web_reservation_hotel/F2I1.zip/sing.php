<?php
if(isset($_GET['p'])){
	$page=$_GET['p'].".php";
}
else{
	$page="index.php";
}
// Login in to c
$errors=[];
if(isset($_POST['login'])){
	$email=mysqli_real_escape_string($conn, $_POST['email']);
	$password=mysqli_real_escape_string($conn, md5($_POST['password']));
	$sql="select * from users where email='$email' and password='$password';";
	$query=mysqli_query($conn, $sql);
	if($query){
		if(mysqli_num_rows($query) == 1){
			$row=mysqli_fetch_array($query, MYSQLI_ASSOC);
			$_SESSION['id_user'] = $row['id_user'];
			$id_user = $_SESSION['id_user'];
			if(isset($_SESSION['cart'])){
				
				$_SESSION['status']=$row['status'];
				$max=count($_SESSION['cart']);
				if($max > 0){
					for($i=0;$i<$max;$i++){
						$pid=$_SESSION['cart'][$i]['productid'];
						$q=$_SESSION['cart'][$i]['qty'];
						$cat=$_SESSION['cart'][$i]['cat'];
						$carte->addtocart($pid,$q,$cat);
						unset($_SESSION['cart'][$i]);
					}
				}
			}
			echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'index.php">';
			}else {
						$errors[]="Votre adress email ou le mot de passe est incorrecte";
					}
		}
	}else if(isset($_POST['register'])){
		if(!empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['gender']) && !empty($_POST['email_reg']) && !empty($_POST['password_reg']) && !empty($_POST['password_reg1'])){
			
			$first_name=mysqli_real_escape_string($conn, $_POST['first_name']);
			$last_name=mysqli_real_escape_string($conn, $_POST['last_name']);
			$email=mysqli_real_escape_string($conn, $_POST['email_reg']);
			$password=mysqli_real_escape_string($conn, $_POST['password_reg']);
			$password1=mysqli_real_escape_string($conn, $_POST['password_reg1']);
			$gender=mysqli_real_escape_string($conn, $_POST['gender']);
			$phone=mysqli_real_escape_string($conn, $_POST['phone']);
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$errors[]="Adress email invalide!";
			}
			if(mb_strlen($password) <= 8){
				$errors[]="Mot de passe trop court! (Minimum 8 caractères)";
			}else{
				if($password != $password1){
				$errors[]="Les deux mots de passe ne concordent pas!";
			    }
			}
			if(is_already_in_use('email', $email, 'users')){
				$errors[]="Adresse E-mail déjà utilisé!";
			}
			if(count($errors) == 0){
				$pass=md5($password);
				$sql="insert into users (first_name, last_name, email, password, phone, gender, status) values('$first_name','$last_name','$email','$pass','$phone','$gender','1')";
				$query=mysqli_query($conn,$sql);
					if($query){
						ob_start();
						$token=sha1($email.$pass);
						$subject = $nom_site." - Activation de compte";
						$from = 'mehdi.ngadibn@gmail.com'; 
						$fromName = 'SenderName'; 
						// Set content-type header for sending HTML email 
						$headers = "MIME-Version: 1.0" . "\r\n"; 
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
						 
						// Additional headers 
						$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 
						require_once("includes/lettre.php");
						mail($email, $subject, $message, $headers);
						echo'<meta http-equiv="refresh" content="0; URL='.$url_site.'login.php?page=email_send">';
					}
			}
		}else{
				$errors[]="Veuillez SVP remplir tous les champs";
			}
} 
?>